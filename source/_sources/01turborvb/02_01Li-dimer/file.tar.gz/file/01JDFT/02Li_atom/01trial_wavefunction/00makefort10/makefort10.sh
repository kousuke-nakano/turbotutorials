makefort10.x < makefort10.input > out_make
mv fort.10_new fort.10
mv fort.10 fort.10_in
convertfort10mol.x < convertfort10mol.input > out_mol
mv fort.10_new fort.10
