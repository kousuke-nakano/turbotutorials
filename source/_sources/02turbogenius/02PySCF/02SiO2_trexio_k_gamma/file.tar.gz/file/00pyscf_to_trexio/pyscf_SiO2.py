#!/usr/bin/env python
# coding: utf-8

# pySCF -> pyscf checkpoint file (SiO2 with single-k)

# load python packages
import os, sys
import numpy as np

# load ASE modules
from ase.io import read

# load pyscf packages
from pyscf import gto, scf, mp, tools
from pyscf.pbc import gto as gto_pbc
from pyscf.pbc import dft as pbcdft
from pyscf.pbc import scf as pbcscf
 
#open boundary condition
structure_file="1011097.cif"
checkpoint_file="SiO2.chk"
pyscf_output="out_SiO2_pyscf"
charge=0
spin=0
basis={
# basis set optimized for solids:
# Correlation-Consistent Gaussian Basis Sets for Solids Made Simple, H.-Z. Ye and T. C. Berkelbach, J. Chem. Theory Comput., 18, 1595--1606 (2022). doi: 10.1021/acs.jctc.1c01245
'Si': gto.basis.parse("""
    #BASIS SET: (5s,4p,2d,1f) -> [3s,3p,2d,1f] Si
    Si  S
     2.741335    4.650395e-02
     1.405628   -3.054975e-01
     0.273354    4.969654e-01
    Si  S
     0.123202    1.000000e+00
    Si  S
     0.055965    1.000000e+00
    Si  P
     1.616545   -3.536164e-02
     0.382436    3.057198e-01
    Si  P
     0.147904    1.000000e+00
    Si  P
     0.055817    1.000000e+00
    Si  D
     0.534081    1.000000e+00
    Si  D
     0.170283    1.000000e+00
    Si  F
     0.347183    1.000000e+00
   """),
'O': gto.basis.parse("""
    #BASIS SET: (7s,7p,2d,1f) -> [3s,3p,2d,1f] O
    O  S
    19.617729    1.415845e-02
     7.154197   -1.740638e-01
     1.137108    3.984802e-01
     0.456668    5.352995e-01
     0.182222    1.954256e-01
    O  S
     2.023130    1.000000e+00
    O  S
     0.267780    1.000000e+00
    O  P
    14.664866    3.867801e-02
     4.563435    1.586589e-01
     1.549011    3.591587e-01
     0.531230    4.522952e-01
     0.173419    2.457321e-01
    O  P
     0.657437    1.000000e+00
    O  P
     0.211337    1.000000e+00
    O  D
     2.353379    1.000000e+00
    O  D
     0.656002    1.000000e+00
    O  F
     1.460952    1.000000e+00
   """)
}
ecp='ccecp'
scf_method="DFT"  # HF or DFT
dft_xc="LDA_X,LDA_C_PZ" # XC for DFT
exp_to_discard = 0.00
twist_average = False
kpt = [0, 0, 0]

print(f"structure file = {structure_file}")
atom=read(structure_file)

# construct a cell
cell=gto_pbc.M()
cell.from_ase(atom)
cell.verbose = 5
cell.output = pyscf_output
cell.charge = charge
cell.spin = spin
cell.symmetry = False
a=cell.a
cell.a=np.array([a[0], a[1], a[2]]) # otherwise, we cannot dump a

# basis set
cell.basis = basis
cell.exp_to_discard=exp_to_discard

# define ecp
cell.ecp = ecp

cell.build(cart=False)

# calc type setting
print(f"scf_method = {scf_method}")  # HF/DFT

if scf_method == "HF":
    # HF calculation
    if cell.spin == 0:
        print("HF kernel=RHF")
        if twist_average:
            print("twist_average=True")
            kpt_grid = cell.make_kpts(kpt_grid)
            mf = pbcscf.khf.KRHF(cell, kpt_grid)
            mf = mf.newton()
        else:
            print("twist_average=False")
            mf = pbcscf.hf.RHF(cell, kpt=cell.get_abs_kpts(scaled_kpts=[kpt])[0])
            mf = mf.newton()
        
    else:
        print("HF kernel=ROHF")
        if twist_average:
            print("twist_average=True")
            kpt_grid = cell.make_kpts(kpt_grid)
            mf = pbcscf.krohf.KROHF(cell, kpt_grid)
            mf = mf.newton()
        else:
            print("twist_average=False")
            mf = pbcscf.rohf.ROHF(cell, kpt=cell.get_abs_kpts(scaled_kpts=[kpt])[0])
            mf = mf.newton()
    
    mf.chkfile = checkpoint_file
    
elif scf_method == "DFT":
    # DFT calculation
    if cell.spin == 0:
        print("DFT kernel=RKS")
        if twist_average:
            print("twist_average=True")
            kpt_grid = cell.make_kpts(kpt_grid)
            mf = pbcdft.krks.KRKS(cell, kpt_grid)
            mf = mf.newton()
            #print(dir(mf))
            #sys.exit()
        else:
            print("twist_average=False")
            mf = pbcdft.rks.RKS(cell, kpt=cell.get_abs_kpts(scaled_kpts=[kpt])[0])
            mf = mf.newton()
    else:
        print("DFT kernel=ROKS")
        if twist_average:
            print("twist_average=True")
            kpt_grid = cell.make_kpts(kpt_grid)
            mf = pbcdft.kroks.KROKS(cell, kpt_grid)
            mf = mf.newton()
        else:
            print("twist_average=False")
            mf = pbcdft.roks.ROKS(cell, kpt=cell.get_abs_kpts(scaled_kpts=[kpt])[0])
            mf = mf.newton()
    
    mf.chkfile = checkpoint_file
    mf.xc = dft_xc
else:
    raise NotImplementedError

total_energy = mf.kernel()

# HF/DFT energy
print(f"Total HF/DFT energy = {total_energy}")
print("HF/DFT calculation is done.")
print("PySCF calculation is done.")
print(f"checkpoint file = {checkpoint_file}")