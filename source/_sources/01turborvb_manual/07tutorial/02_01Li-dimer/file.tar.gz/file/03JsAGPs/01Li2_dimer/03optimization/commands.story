set title "Fort.22 Par"
set xlabel "x"
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              2
pause -1
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              3
pause -1
set ylabel  "Orbital Z Parameter               1"
plot "story.d"  using 1:              4
pause -1
set ylabel  "Orbital Z Parameter               2"
plot "story.d"  using 1:              5
pause -1
set ylabel  "Orbital Z Parameter               3"
plot "story.d"  using 1:              6
pause -1
set ylabel  "Orbital Z Parameter               4"
plot "story.d"  using 1:              7
pause -1
set ylabel  "Orbital Z Parameter               5"
plot "story.d"  using 1:              8
pause -1
set ylabel  "Orbital Z Parameter               6"
plot "story.d"  using 1:              9
pause -1
set ylabel  "Orbital Z Parameter               7"
plot "story.d"  using 1:             10
pause -1
set ylabel  "Orbital Z Parameter               8"
plot "story.d"  using 1:             11
pause -1
set ylabel  "Orbital Z Parameter               9"
plot "story.d"  using 1:             12
pause -1
set ylabel  "Orbital Z Parameter              10"
plot "story.d"  using 1:             13
pause -1
set ylabel  "Orbital Z Parameter              11"
plot "story.d"  using 1:             14
pause -1
set ylabel  "Orbital Z Parameter              12"
plot "story.d"  using 1:             15
pause -1
set ylabel  "Orbital Z Parameter              13"
plot "story.d"  using 1:             16
pause -1
set ylabel  "Orbital Z Parameter              14"
plot "story.d"  using 1:             17
pause -1
set ylabel  "Orbital Z Parameter              15"
plot "story.d"  using 1:             18
pause -1
set ylabel  "Orbital Z Parameter              16"
plot "story.d"  using 1:             19
pause -1
set ylabel  "Orbital Z Parameter              17"
plot "story.d"  using 1:             20
pause -1
set ylabel  "Orbital Z Parameter              18"
plot "story.d"  using 1:             21
pause -1
set ylabel  "Orbital Z Parameter              19"
plot "story.d"  using 1:             22
pause -1
set ylabel  "Orbital Z Parameter              20"
plot "story.d"  using 1:             23
pause -1
set ylabel  "Orbital Z Parameter              21"
plot "story.d"  using 1:             24
pause -1
set ylabel  "Orbital Z Parameter              22"
plot "story.d"  using 1:             25
pause -1
set ylabel  "Orbital Z Parameter              23"
plot "story.d"  using 1:             26
pause -1
set ylabel  "Orbital Z Parameter              24"
plot "story.d"  using 1:             27
pause -1
set ylabel  "Orbital Z Parameter              25"
plot "story.d"  using 1:             28
pause -1
set ylabel  "Orbital Z Parameter              26"
plot "story.d"  using 1:             29
pause -1
set ylabel  "Orbital Z Parameter              27"
plot "story.d"  using 1:             30
pause -1
set ylabel  "Orbital Z Parameter              28"
plot "story.d"  using 1:             31
pause -1
set ylabel  "Orbital Z Parameter              29"
plot "story.d"  using 1:             32
pause -1
set ylabel  "Orbital Z Parameter              30"
plot "story.d"  using 1:             33
pause -1
set ylabel  "Orbital Z Parameter              31"
plot "story.d"  using 1:             34
pause -1
set ylabel  "Orbital Z Parameter              32"
plot "story.d"  using 1:             35
pause -1
set ylabel  "Orbital Z Parameter              33"
plot "story.d"  using 1:             36
pause -1
set ylabel  "Orbital Z Parameter              34"
plot "story.d"  using 1:             37
pause -1
set ylabel  "Orbital Z Parameter              35"
plot "story.d"  using 1:             38
pause -1
set ylabel  "Orbital Z Parameter              36"
plot "story.d"  using 1:             39
pause -1
set ylabel  "Orbital Z Parameter              37"
plot "story.d"  using 1:             40
pause -1
set ylabel  "Orbital Z Parameter              38"
plot "story.d"  using 1:             41
pause -1
set ylabel  "Orbital Z Parameter              39"
plot "story.d"  using 1:             42
pause -1
set ylabel  "Orbital Z Parameter              40"
plot "story.d"  using 1:             43
pause -1
set ylabel  "Orbital Z Parameter              41"
plot "story.d"  using 1:             44
pause -1
set ylabel  "Orbital Z Parameter              42"
plot "story.d"  using 1:             45
pause -1
set ylabel  "Orbital Z Parameter              43"
plot "story.d"  using 1:             46
pause -1
set ylabel  "Orbital Z Parameter              44"
plot "story.d"  using 1:             47
pause -1
set ylabel  "Orbital Z Parameter              45"
plot "story.d"  using 1:             48
pause -1
set ylabel  "Orbital Z Parameter              46"
plot "story.d"  using 1:             49
pause -1
set ylabel  "Orbital Z Parameter              47"
plot "story.d"  using 1:             50
pause -1
set ylabel  "Orbital Z Parameter              48"
plot "story.d"  using 1:             51
pause -1
set ylabel  "Orbital Z Parameter              49"
plot "story.d"  using 1:             52
pause -1
set ylabel  "Orbital Z Parameter              50"
plot "story.d"  using 1:             53
pause -1
set ylabel  "Orbital Z Parameter              51"
plot "story.d"  using 1:             54
pause -1
set ylabel  "Orbital Z Parameter              52"
plot "story.d"  using 1:             55
pause -1
set ylabel  "Orbital Z Parameter              53"
plot "story.d"  using 1:             56
pause -1
set ylabel  "Orbital Z Parameter              54"
plot "story.d"  using 1:             57
pause -1
set ylabel  "Orbital Z Parameter              55"
plot "story.d"  using 1:             58
pause -1
set ylabel  "Orbital Z Parameter              56"
plot "story.d"  using 1:             59
pause -1
set ylabel  "Orbital Z Parameter              57"
plot "story.d"  using 1:             60
pause -1
set ylabel  "Orbital Z Parameter              58"
plot "story.d"  using 1:             61
pause -1
set ylabel  "Orbital Z Parameter              59"
plot "story.d"  using 1:             62
pause -1
set ylabel  "Orbital Z Parameter              60"
plot "story.d"  using 1:             63
pause -1
set ylabel  "Orbital Z Parameter              61"
plot "story.d"  using 1:             64
pause -1
set ylabel  "Orbital Z Parameter              62"
plot "story.d"  using 1:             65
pause -1
set ylabel  "Orbital Z Parameter              63"
plot "story.d"  using 1:             66
pause -1
set ylabel  "Orbital Z Parameter              64"
plot "story.d"  using 1:             67
pause -1
set ylabel  "Orbital Z Parameter              65"
plot "story.d"  using 1:             68
pause -1
set ylabel  "Orbital Z Parameter              66"
plot "story.d"  using 1:             69
pause -1
set ylabel  "Orbital Z Parameter              67"
plot "story.d"  using 1:             70
pause -1
set ylabel  "Orbital Z Parameter              68"
plot "story.d"  using 1:             71
pause -1
set ylabel  "Orbital Z Parameter              69"
plot "story.d"  using 1:             72
pause -1
set ylabel  "Orbital Z Parameter              70"
plot "story.d"  using 1:             73
pause -1
set ylabel  "Orbital Z Parameter              71"
plot "story.d"  using 1:             74
pause -1
set ylabel  "Orbital Z Parameter              72"
plot "story.d"  using 1:             75
pause -1
set ylabel  "Orbital Z Parameter              73"
plot "story.d"  using 1:             76
pause -1
set ylabel  "Orbital Z Parameter              74"
plot "story.d"  using 1:             77
pause -1
set ylabel  "Orbital Z Parameter              75"
plot "story.d"  using 1:             78
pause -1
set ylabel  "Orbital Z Parameter              76"
plot "story.d"  using 1:             79
pause -1
set ylabel  "Orbital Z Parameter              77"
plot "story.d"  using 1:             80
pause -1
set ylabel  "Orbital Z Parameter              78"
plot "story.d"  using 1:             81
pause -1
set ylabel  "Orbital Z Parameter              79"
plot "story.d"  using 1:             82
pause -1
set ylabel  "Orbital Z Parameter              80"
plot "story.d"  using 1:             83
pause -1
set ylabel  "Orbital Z Parameter              81"
plot "story.d"  using 1:             84
pause -1
set ylabel  "Orbital Z Parameter              82"
plot "story.d"  using 1:             85
pause -1
set ylabel  "Orbital Z Parameter              83"
plot "story.d"  using 1:             86
pause -1
set ylabel  "Orbital Z Parameter              84"
plot "story.d"  using 1:             87
pause -1
set ylabel  "Orbital Z Parameter              85"
plot "story.d"  using 1:             88
pause -1
set ylabel  "Orbital Z Parameter              86"
plot "story.d"  using 1:             89
pause -1
set ylabel  "Orbital Z Parameter              87"
plot "story.d"  using 1:             90
pause -1
set ylabel  "Orbital Z Parameter              88"
plot "story.d"  using 1:             91
pause -1
set ylabel  "Orbital Z Parameter              89"
plot "story.d"  using 1:             92
pause -1
set ylabel  "Orbital Z Parameter              90"
plot "story.d"  using 1:             93
pause -1
set ylabel  "Orbital Z Parameter              91"
plot "story.d"  using 1:             94
pause -1
set ylabel  "Orbital Z Parameter              92"
plot "story.d"  using 1:             95
pause -1
set ylabel  "Orbital Z Parameter              93"
plot "story.d"  using 1:             96
pause -1
set ylabel  "Orbital Z Parameter              94"
plot "story.d"  using 1:             97
pause -1
set ylabel  "Orbital Z Parameter              95"
plot "story.d"  using 1:             98
pause -1
set ylabel "Three Body Parameter Matrix               1"
plot "story.d"  using 1:             99
pause -1
set ylabel "Three Body Parameter Matrix               2"
plot "story.d"  using 1:            100
pause -1
set ylabel "Three Body Parameter Matrix               3"
plot "story.d"  using 1:            101
pause -1
set ylabel "Three Body Parameter Matrix               4"
plot "story.d"  using 1:            102
pause -1
set ylabel "Three Body Parameter Matrix               5"
plot "story.d"  using 1:            103
pause -1
set ylabel "Three Body Parameter Matrix               6"
plot "story.d"  using 1:            104
pause -1
set ylabel "Three Body Parameter Matrix               7"
plot "story.d"  using 1:            105
pause -1
set ylabel "Three Body Parameter Matrix               8"
plot "story.d"  using 1:            106
pause -1
set ylabel "Three Body Parameter Matrix               9"
plot "story.d"  using 1:            107
pause -1
set ylabel "Three Body Parameter Matrix              10"
plot "story.d"  using 1:            108
pause -1
set ylabel "Three Body Parameter Matrix              11"
plot "story.d"  using 1:            109
pause -1
set ylabel "Three Body Parameter Matrix              12"
plot "story.d"  using 1:            110
pause -1
set ylabel "Three Body Parameter Matrix              13"
plot "story.d"  using 1:            111
pause -1
set ylabel "Three Body Parameter Matrix              14"
plot "story.d"  using 1:            112
pause -1
set ylabel "Three Body Parameter Matrix              15"
plot "story.d"  using 1:            113
pause -1
set ylabel "Three Body Parameter Matrix              16"
plot "story.d"  using 1:            114
pause -1
set ylabel "Three Body Parameter Matrix              17"
plot "story.d"  using 1:            115
pause -1
set ylabel "Three Body Parameter Matrix              18"
plot "story.d"  using 1:            116
pause -1
set ylabel "Three Body Parameter Matrix              19"
plot "story.d"  using 1:            117
pause -1
set ylabel "Three Body Parameter Matrix              20"
plot "story.d"  using 1:            118
pause -1
set ylabel "Three Body Parameter Matrix              21"
plot "story.d"  using 1:            119
pause -1
set ylabel "Three Body Parameter Matrix              22"
plot "story.d"  using 1:            120
pause -1
set ylabel "Three Body Parameter Matrix              23"
plot "story.d"  using 1:            121
pause -1
set ylabel "Three Body Parameter Matrix              24"
plot "story.d"  using 1:            122
pause -1
set ylabel "Three Body Parameter Matrix              25"
plot "story.d"  using 1:            123
pause -1
set ylabel "Three Body Parameter Matrix              26"
plot "story.d"  using 1:            124
pause -1
set ylabel "Three Body Parameter Matrix              27"
plot "story.d"  using 1:            125
pause -1
set ylabel "Three Body Parameter Matrix              28"
plot "story.d"  using 1:            126
pause -1
set ylabel "Three Body Parameter Matrix              29"
plot "story.d"  using 1:            127
pause -1
set ylabel "Three Body Parameter Matrix              30"
plot "story.d"  using 1:            128
pause -1
set ylabel "Three Body Parameter Matrix              31"
plot "story.d"  using 1:            129
pause -1
set ylabel "Three Body Parameter Matrix              32"
plot "story.d"  using 1:            130
pause -1
set ylabel "Three Body Parameter Matrix              33"
plot "story.d"  using 1:            131
pause -1
set ylabel "Three Body Parameter Matrix              34"
plot "story.d"  using 1:            132
pause -1
set ylabel "Three Body Parameter Matrix              35"
plot "story.d"  using 1:            133
pause -1
set ylabel "Three Body Parameter Matrix              36"
plot "story.d"  using 1:            134
pause -1
set ylabel "Three Body Parameter Matrix              37"
plot "story.d"  using 1:            135
pause -1
set ylabel "Three Body Parameter Matrix              38"
plot "story.d"  using 1:            136
pause -1
set ylabel "Three Body Parameter Matrix              39"
plot "story.d"  using 1:            137
pause -1
set ylabel "Three Body Parameter Matrix              40"
plot "story.d"  using 1:            138
pause -1
set ylabel "Three Body Parameter Matrix              41"
plot "story.d"  using 1:            139
pause -1
set ylabel  "Det Matrix               1"
plot "story.d"  using 1:            140
pause -1
set ylabel  "Det Matrix               2"
plot "story.d"  using 1:            141
pause -1
set ylabel  "Det Matrix               3"
plot "story.d"  using 1:            142
pause -1
set ylabel  "Det Matrix               4"
plot "story.d"  using 1:            143
pause -1
set ylabel  "Det Matrix               5"
plot "story.d"  using 1:            144
pause -1
set ylabel  "Det Matrix               6"
plot "story.d"  using 1:            145
pause -1
set ylabel  "Det Matrix               7"
plot "story.d"  using 1:            146
pause -1
set ylabel  "Det Matrix               8"
plot "story.d"  using 1:            147
pause -1
set ylabel  "Det Matrix               9"
plot "story.d"  using 1:            148
pause -1
q
