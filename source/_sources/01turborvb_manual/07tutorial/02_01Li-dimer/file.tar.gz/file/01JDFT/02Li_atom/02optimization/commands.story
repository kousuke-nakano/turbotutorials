set title "Fort.22 Par"
set xlabel "x"
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              2
pause -1
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              3
pause -1
set ylabel "Three Body Parameter Matrix               1"
plot "story.d"  using 1:              4
pause -1
set ylabel "Three Body Parameter Matrix               2"
plot "story.d"  using 1:              5
pause -1
set ylabel "Three Body Parameter Matrix               3"
plot "story.d"  using 1:              6
pause -1
set ylabel "Three Body Parameter Matrix               4"
plot "story.d"  using 1:              7
pause -1
set ylabel "Three Body Parameter Matrix               5"
plot "story.d"  using 1:              8
pause -1
set ylabel "Three Body Parameter Matrix               6"
plot "story.d"  using 1:              9
pause -1
set ylabel "Three Body Parameter Matrix               7"
plot "story.d"  using 1:             10
pause -1
set ylabel "Three Body Parameter Matrix               8"
plot "story.d"  using 1:             11
pause -1
set ylabel "Three Body Parameter Matrix               9"
plot "story.d"  using 1:             12
pause -1
set ylabel "Three Body Parameter Matrix              10"
plot "story.d"  using 1:             13
pause -1
set ylabel "Three Body Parameter Matrix              11"
plot "story.d"  using 1:             14
pause -1
set ylabel "Three Body Parameter Matrix              12"
plot "story.d"  using 1:             15
pause -1
q
