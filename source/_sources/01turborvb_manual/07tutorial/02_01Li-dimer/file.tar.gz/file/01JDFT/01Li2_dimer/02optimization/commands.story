set title "Fort.22 Par"
set xlabel "x"
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              2
pause -1
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              3
pause -1
set ylabel "Three Body Parameter Matrix               1"
plot "story.d"  using 1:              4
pause -1
set ylabel "Three Body Parameter Matrix               2"
plot "story.d"  using 1:              5
pause -1
set ylabel "Three Body Parameter Matrix               3"
plot "story.d"  using 1:              6
pause -1
set ylabel "Three Body Parameter Matrix               4"
plot "story.d"  using 1:              7
pause -1
set ylabel "Three Body Parameter Matrix               5"
plot "story.d"  using 1:              8
pause -1
set ylabel "Three Body Parameter Matrix               6"
plot "story.d"  using 1:              9
pause -1
set ylabel "Three Body Parameter Matrix               7"
plot "story.d"  using 1:             10
pause -1
set ylabel "Three Body Parameter Matrix               8"
plot "story.d"  using 1:             11
pause -1
set ylabel "Three Body Parameter Matrix               9"
plot "story.d"  using 1:             12
pause -1
set ylabel "Three Body Parameter Matrix              10"
plot "story.d"  using 1:             13
pause -1
set ylabel "Three Body Parameter Matrix              11"
plot "story.d"  using 1:             14
pause -1
set ylabel "Three Body Parameter Matrix              12"
plot "story.d"  using 1:             15
pause -1
set ylabel "Three Body Parameter Matrix              13"
plot "story.d"  using 1:             16
pause -1
set ylabel "Three Body Parameter Matrix              14"
plot "story.d"  using 1:             17
pause -1
set ylabel "Three Body Parameter Matrix              15"
plot "story.d"  using 1:             18
pause -1
set ylabel "Three Body Parameter Matrix              16"
plot "story.d"  using 1:             19
pause -1
set ylabel "Three Body Parameter Matrix              17"
plot "story.d"  using 1:             20
pause -1
set ylabel "Three Body Parameter Matrix              18"
plot "story.d"  using 1:             21
pause -1
set ylabel "Three Body Parameter Matrix              19"
plot "story.d"  using 1:             22
pause -1
set ylabel "Three Body Parameter Matrix              20"
plot "story.d"  using 1:             23
pause -1
set ylabel "Three Body Parameter Matrix              21"
plot "story.d"  using 1:             24
pause -1
set ylabel "Three Body Parameter Matrix              22"
plot "story.d"  using 1:             25
pause -1
set ylabel "Three Body Parameter Matrix              23"
plot "story.d"  using 1:             26
pause -1
set ylabel "Three Body Parameter Matrix              24"
plot "story.d"  using 1:             27
pause -1
set ylabel "Three Body Parameter Matrix              25"
plot "story.d"  using 1:             28
pause -1
set ylabel "Three Body Parameter Matrix              26"
plot "story.d"  using 1:             29
pause -1
set ylabel "Three Body Parameter Matrix              27"
plot "story.d"  using 1:             30
pause -1
set ylabel "Three Body Parameter Matrix              28"
plot "story.d"  using 1:             31
pause -1
set ylabel "Three Body Parameter Matrix              29"
plot "story.d"  using 1:             32
pause -1
set ylabel "Three Body Parameter Matrix              30"
plot "story.d"  using 1:             33
pause -1
set ylabel "Three Body Parameter Matrix              31"
plot "story.d"  using 1:             34
pause -1
set ylabel "Three Body Parameter Matrix              32"
plot "story.d"  using 1:             35
pause -1
set ylabel "Three Body Parameter Matrix              33"
plot "story.d"  using 1:             36
pause -1
set ylabel "Three Body Parameter Matrix              34"
plot "story.d"  using 1:             37
pause -1
set ylabel "Three Body Parameter Matrix              35"
plot "story.d"  using 1:             38
pause -1
set ylabel "Three Body Parameter Matrix              36"
plot "story.d"  using 1:             39
pause -1
set ylabel "Three Body Parameter Matrix              37"
plot "story.d"  using 1:             40
pause -1
set ylabel "Three Body Parameter Matrix              38"
plot "story.d"  using 1:             41
pause -1
set ylabel "Three Body Parameter Matrix              39"
plot "story.d"  using 1:             42
pause -1
set ylabel "Three Body Parameter Matrix              40"
plot "story.d"  using 1:             43
pause -1
set ylabel "Three Body Parameter Matrix              41"
plot "story.d"  using 1:             44
pause -1
q
