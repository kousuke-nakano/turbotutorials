set title "Fort.22 Par"
set xlabel "x"
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              2
pause -1
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              3
pause -1
set ylabel  "Orbital Z Parameter               1"
plot "story.d"  using 1:              4
pause -1
set ylabel  "Orbital Z Parameter               2"
plot "story.d"  using 1:              5
pause -1
set ylabel  "Orbital Z Parameter               3"
plot "story.d"  using 1:              6
pause -1
set ylabel  "Orbital Z Parameter               4"
plot "story.d"  using 1:              7
pause -1
set ylabel  "Orbital Z Parameter               5"
plot "story.d"  using 1:              8
pause -1
set ylabel  "Orbital Z Parameter               6"
plot "story.d"  using 1:              9
pause -1
set ylabel  "Orbital Z Parameter               7"
plot "story.d"  using 1:             10
pause -1
set ylabel  "Orbital Z Parameter               8"
plot "story.d"  using 1:             11
pause -1
set ylabel  "Orbital Z Parameter               9"
plot "story.d"  using 1:             12
pause -1
set ylabel  "Orbital Z Parameter              10"
plot "story.d"  using 1:             13
pause -1
set ylabel  "Orbital Z Parameter              11"
plot "story.d"  using 1:             14
pause -1
set ylabel  "Orbital Z Parameter              12"
plot "story.d"  using 1:             15
pause -1
set ylabel  "Orbital Z Parameter              13"
plot "story.d"  using 1:             16
pause -1
set ylabel  "Orbital Z Parameter              14"
plot "story.d"  using 1:             17
pause -1
set ylabel  "Orbital Z Parameter              15"
plot "story.d"  using 1:             18
pause -1
set ylabel  "Orbital Z Parameter              16"
plot "story.d"  using 1:             19
pause -1
set ylabel  "Orbital Z Parameter              17"
plot "story.d"  using 1:             20
pause -1
set ylabel  "Orbital Z Parameter              18"
plot "story.d"  using 1:             21
pause -1
set ylabel  "Orbital Z Parameter              19"
plot "story.d"  using 1:             22
pause -1
set ylabel  "Orbital Z Parameter              20"
plot "story.d"  using 1:             23
pause -1
set ylabel  "Orbital Z Parameter              21"
plot "story.d"  using 1:             24
pause -1
set ylabel  "Orbital Z Parameter              22"
plot "story.d"  using 1:             25
pause -1
set ylabel  "Orbital Z Parameter              23"
plot "story.d"  using 1:             26
pause -1
set ylabel  "Orbital Z Parameter              24"
plot "story.d"  using 1:             27
pause -1
set ylabel  "Orbital Z Parameter              25"
plot "story.d"  using 1:             28
pause -1
set ylabel  "Orbital Z Parameter              26"
plot "story.d"  using 1:             29
pause -1
set ylabel  "Orbital Z Parameter              27"
plot "story.d"  using 1:             30
pause -1
set ylabel  "Orbital Z Parameter              28"
plot "story.d"  using 1:             31
pause -1
set ylabel  "Orbital Z Parameter              29"
plot "story.d"  using 1:             32
pause -1
set ylabel  "Orbital Z Parameter              30"
plot "story.d"  using 1:             33
pause -1
set ylabel  "Orbital Z Parameter              31"
plot "story.d"  using 1:             34
pause -1
set ylabel  "Orbital Z Parameter              32"
plot "story.d"  using 1:             35
pause -1
set ylabel  "Orbital Z Parameter              33"
plot "story.d"  using 1:             36
pause -1
set ylabel  "Orbital Z Parameter              34"
plot "story.d"  using 1:             37
pause -1
set ylabel  "Orbital Z Parameter              35"
plot "story.d"  using 1:             38
pause -1
set ylabel  "Orbital Z Parameter              36"
plot "story.d"  using 1:             39
pause -1
set ylabel  "Orbital Z Parameter              37"
plot "story.d"  using 1:             40
pause -1
set ylabel  "Orbital Z Parameter              38"
plot "story.d"  using 1:             41
pause -1
set ylabel  "Orbital Z Parameter              39"
plot "story.d"  using 1:             42
pause -1
set ylabel  "Orbital Z Parameter              40"
plot "story.d"  using 1:             43
pause -1
set ylabel  "Orbital Z Parameter              41"
plot "story.d"  using 1:             44
pause -1
set ylabel  "Orbital Z Parameter              42"
plot "story.d"  using 1:             45
pause -1
set ylabel  "Orbital Z Parameter              43"
plot "story.d"  using 1:             46
pause -1
set ylabel  "Orbital Z Parameter              44"
plot "story.d"  using 1:             47
pause -1
set ylabel  "Orbital Z Parameter              45"
plot "story.d"  using 1:             48
pause -1
set ylabel  "Orbital Z Parameter              46"
plot "story.d"  using 1:             49
pause -1
set ylabel  "Orbital Z Parameter              47"
plot "story.d"  using 1:             50
pause -1
set ylabel  "Orbital Z Parameter              48"
plot "story.d"  using 1:             51
pause -1
set ylabel  "Orbital Z Parameter              49"
plot "story.d"  using 1:             52
pause -1
set ylabel  "Orbital Z Parameter              50"
plot "story.d"  using 1:             53
pause -1
set ylabel  "Orbital Z Parameter              51"
plot "story.d"  using 1:             54
pause -1
set ylabel  "Orbital Z Parameter              52"
plot "story.d"  using 1:             55
pause -1
set ylabel  "Orbital Z Parameter              53"
plot "story.d"  using 1:             56
pause -1
set ylabel  "Orbital Z Parameter              54"
plot "story.d"  using 1:             57
pause -1
set ylabel  "Orbital Z Parameter              55"
plot "story.d"  using 1:             58
pause -1
set ylabel  "Orbital Z Parameter              56"
plot "story.d"  using 1:             59
pause -1
set ylabel  "Orbital Z Parameter              57"
plot "story.d"  using 1:             60
pause -1
set ylabel  "Orbital Z Parameter              58"
plot "story.d"  using 1:             61
pause -1
set ylabel  "Orbital Z Parameter              59"
plot "story.d"  using 1:             62
pause -1
set ylabel  "Orbital Z Parameter              60"
plot "story.d"  using 1:             63
pause -1
set ylabel  "Orbital Z Parameter              61"
plot "story.d"  using 1:             64
pause -1
set ylabel  "Orbital Z Parameter              62"
plot "story.d"  using 1:             65
pause -1
set ylabel  "Orbital Z Parameter              63"
plot "story.d"  using 1:             66
pause -1
set ylabel  "Orbital Z Parameter              64"
plot "story.d"  using 1:             67
pause -1
set ylabel  "Orbital Z Parameter              65"
plot "story.d"  using 1:             68
pause -1
set ylabel  "Orbital Z Parameter              66"
plot "story.d"  using 1:             69
pause -1
set ylabel  "Orbital Z Parameter              67"
plot "story.d"  using 1:             70
pause -1
set ylabel  "Orbital Z Parameter              68"
plot "story.d"  using 1:             71
pause -1
set ylabel  "Orbital Z Parameter              69"
plot "story.d"  using 1:             72
pause -1
set ylabel  "Orbital Z Parameter              70"
plot "story.d"  using 1:             73
pause -1
set ylabel  "Orbital Z Parameter              71"
plot "story.d"  using 1:             74
pause -1
set ylabel  "Orbital Z Parameter              72"
plot "story.d"  using 1:             75
pause -1
set ylabel  "Orbital Z Parameter              73"
plot "story.d"  using 1:             76
pause -1
set ylabel  "Orbital Z Parameter              74"
plot "story.d"  using 1:             77
pause -1
set ylabel  "Orbital Z Parameter              75"
plot "story.d"  using 1:             78
pause -1
set ylabel  "Orbital Z Parameter              76"
plot "story.d"  using 1:             79
pause -1
set ylabel  "Orbital Z Parameter              77"
plot "story.d"  using 1:             80
pause -1
set ylabel  "Orbital Z Parameter              78"
plot "story.d"  using 1:             81
pause -1
set ylabel  "Orbital Z Parameter              79"
plot "story.d"  using 1:             82
pause -1
set ylabel  "Orbital Z Parameter              80"
plot "story.d"  using 1:             83
pause -1
set ylabel  "Orbital Z Parameter              81"
plot "story.d"  using 1:             84
pause -1
set ylabel  "Orbital Z Parameter              82"
plot "story.d"  using 1:             85
pause -1
set ylabel  "Orbital Z Parameter              83"
plot "story.d"  using 1:             86
pause -1
set ylabel  "Orbital Z Parameter              84"
plot "story.d"  using 1:             87
pause -1
set ylabel  "Orbital Z Parameter              85"
plot "story.d"  using 1:             88
pause -1
set ylabel  "Orbital Z Parameter              86"
plot "story.d"  using 1:             89
pause -1
set ylabel  "Orbital Z Parameter              87"
plot "story.d"  using 1:             90
pause -1
set ylabel  "Orbital Z Parameter              88"
plot "story.d"  using 1:             91
pause -1
set ylabel  "Orbital Z Parameter              89"
plot "story.d"  using 1:             92
pause -1
set ylabel  "Orbital Z Parameter              90"
plot "story.d"  using 1:             93
pause -1
set ylabel  "Orbital Z Parameter              91"
plot "story.d"  using 1:             94
pause -1
set ylabel  "Orbital Z Parameter              92"
plot "story.d"  using 1:             95
pause -1
set ylabel  "Orbital Z Parameter              93"
plot "story.d"  using 1:             96
pause -1
set ylabel  "Orbital Z Parameter              94"
plot "story.d"  using 1:             97
pause -1
set ylabel  "Orbital Z Parameter              95"
plot "story.d"  using 1:             98
pause -1
set ylabel  "Orbital Z Parameter              96"
plot "story.d"  using 1:             99
pause -1
set ylabel  "Orbital Z Parameter              97"
plot "story.d"  using 1:            100
pause -1
set ylabel  "Orbital Z Parameter              98"
plot "story.d"  using 1:            101
pause -1
set ylabel  "Orbital Z Parameter              99"
plot "story.d"  using 1:            102
pause -1
set ylabel  "Orbital Z Parameter             100"
plot "story.d"  using 1:            103
pause -1
set ylabel  "Orbital Z Parameter             101"
plot "story.d"  using 1:            104
pause -1
set ylabel  "Orbital Z Parameter             102"
plot "story.d"  using 1:            105
pause -1
set ylabel  "Orbital Z Parameter             103"
plot "story.d"  using 1:            106
pause -1
set ylabel  "Orbital Z Parameter             104"
plot "story.d"  using 1:            107
pause -1
set ylabel  "Orbital Z Parameter             105"
plot "story.d"  using 1:            108
pause -1
set ylabel  "Orbital Z Parameter             106"
plot "story.d"  using 1:            109
pause -1
set ylabel  "Orbital Z Parameter             107"
plot "story.d"  using 1:            110
pause -1
set ylabel  "Orbital Z Parameter             108"
plot "story.d"  using 1:            111
pause -1
set ylabel  "Orbital Z Parameter             109"
plot "story.d"  using 1:            112
pause -1
set ylabel  "Orbital Z Parameter             110"
plot "story.d"  using 1:            113
pause -1
set ylabel  "Orbital Z Parameter             111"
plot "story.d"  using 1:            114
pause -1
set ylabel  "Orbital Z Parameter             112"
plot "story.d"  using 1:            115
pause -1
set ylabel  "Orbital Z Parameter             113"
plot "story.d"  using 1:            116
pause -1
set ylabel  "Orbital Z Parameter             114"
plot "story.d"  using 1:            117
pause -1
set ylabel  "Orbital Z Parameter             115"
plot "story.d"  using 1:            118
pause -1
set ylabel  "Orbital Z Parameter             116"
plot "story.d"  using 1:            119
pause -1
set ylabel  "Orbital Z Parameter             117"
plot "story.d"  using 1:            120
pause -1
set ylabel  "Orbital Z Parameter             118"
plot "story.d"  using 1:            121
pause -1
set ylabel  "Orbital Z Parameter             119"
plot "story.d"  using 1:            122
pause -1
set ylabel  "Orbital Z Parameter             120"
plot "story.d"  using 1:            123
pause -1
set ylabel  "Orbital Z Parameter             121"
plot "story.d"  using 1:            124
pause -1
set ylabel  "Orbital Z Parameter             122"
plot "story.d"  using 1:            125
pause -1
set ylabel  "Orbital Z Parameter             123"
plot "story.d"  using 1:            126
pause -1
set ylabel  "Orbital Z Parameter             124"
plot "story.d"  using 1:            127
pause -1
set ylabel  "Orbital Z Parameter             125"
plot "story.d"  using 1:            128
pause -1
set ylabel  "Orbital Z Parameter             126"
plot "story.d"  using 1:            129
pause -1
set ylabel  "Orbital Z Parameter             127"
plot "story.d"  using 1:            130
pause -1
set ylabel  "Orbital Z Parameter             128"
plot "story.d"  using 1:            131
pause -1
set ylabel  "Orbital Z Parameter             129"
plot "story.d"  using 1:            132
pause -1
set ylabel  "Orbital Z Parameter             130"
plot "story.d"  using 1:            133
pause -1
set ylabel  "Orbital Z Parameter             131"
plot "story.d"  using 1:            134
pause -1
set ylabel  "Orbital Z Parameter             132"
plot "story.d"  using 1:            135
pause -1
set ylabel  "Orbital Z Parameter             133"
plot "story.d"  using 1:            136
pause -1
set ylabel  "Orbital Z Parameter             134"
plot "story.d"  using 1:            137
pause -1
set ylabel  "Orbital Z Parameter             135"
plot "story.d"  using 1:            138
pause -1
set ylabel  "Orbital Z Parameter             136"
plot "story.d"  using 1:            139
pause -1
set ylabel  "Orbital Z Parameter             137"
plot "story.d"  using 1:            140
pause -1
set ylabel  "Orbital Z Parameter             138"
plot "story.d"  using 1:            141
pause -1
set ylabel  "Orbital Z Parameter             139"
plot "story.d"  using 1:            142
pause -1
set ylabel  "Orbital Z Parameter             140"
plot "story.d"  using 1:            143
pause -1
set ylabel  "Orbital Z Parameter             141"
plot "story.d"  using 1:            144
pause -1
set ylabel  "Orbital Z Parameter             142"
plot "story.d"  using 1:            145
pause -1
set ylabel  "Orbital Z Parameter             143"
plot "story.d"  using 1:            146
pause -1
set ylabel  "Orbital Z Parameter             144"
plot "story.d"  using 1:            147
pause -1
set ylabel  "Orbital Z Parameter             145"
plot "story.d"  using 1:            148
pause -1
set ylabel  "Orbital Z Parameter             146"
plot "story.d"  using 1:            149
pause -1
set ylabel  "Orbital Z Parameter             147"
plot "story.d"  using 1:            150
pause -1
set ylabel  "Orbital Z Parameter             148"
plot "story.d"  using 1:            151
pause -1
set ylabel  "Orbital Z Parameter             149"
plot "story.d"  using 1:            152
pause -1
set ylabel  "Orbital Z Parameter             150"
plot "story.d"  using 1:            153
pause -1
set ylabel  "Orbital Z Parameter             151"
plot "story.d"  using 1:            154
pause -1
set ylabel  "Orbital Z Parameter             152"
plot "story.d"  using 1:            155
pause -1
set ylabel  "Orbital Z Parameter             153"
plot "story.d"  using 1:            156
pause -1
set ylabel  "Orbital Z Parameter             154"
plot "story.d"  using 1:            157
pause -1
set ylabel  "Orbital Z Parameter             155"
plot "story.d"  using 1:            158
pause -1
set ylabel  "Orbital Z Parameter             156"
plot "story.d"  using 1:            159
pause -1
set ylabel  "Orbital Z Parameter             157"
plot "story.d"  using 1:            160
pause -1
set ylabel  "Orbital Z Parameter             158"
plot "story.d"  using 1:            161
pause -1
set ylabel  "Orbital Z Parameter             159"
plot "story.d"  using 1:            162
pause -1
set ylabel  "Orbital Z Parameter             160"
plot "story.d"  using 1:            163
pause -1
set ylabel  "Orbital Z Parameter             161"
plot "story.d"  using 1:            164
pause -1
set ylabel  "Orbital Z Parameter             162"
plot "story.d"  using 1:            165
pause -1
set ylabel  "Orbital Z Parameter             163"
plot "story.d"  using 1:            166
pause -1
set ylabel  "Orbital Z Parameter             164"
plot "story.d"  using 1:            167
pause -1
set ylabel  "Orbital Z Parameter             165"
plot "story.d"  using 1:            168
pause -1
set ylabel  "Orbital Z Parameter             166"
plot "story.d"  using 1:            169
pause -1
set ylabel  "Orbital Z Parameter             167"
plot "story.d"  using 1:            170
pause -1
set ylabel  "Orbital Z Parameter             168"
plot "story.d"  using 1:            171
pause -1
set ylabel  "Orbital Z Parameter             169"
plot "story.d"  using 1:            172
pause -1
set ylabel  "Orbital Z Parameter             170"
plot "story.d"  using 1:            173
pause -1
set ylabel  "Orbital Z Parameter             171"
plot "story.d"  using 1:            174
pause -1
set ylabel  "Orbital Z Parameter             172"
plot "story.d"  using 1:            175
pause -1
set ylabel  "Orbital Z Parameter             173"
plot "story.d"  using 1:            176
pause -1
set ylabel  "Orbital Z Parameter             174"
plot "story.d"  using 1:            177
pause -1
set ylabel  "Orbital Z Parameter             175"
plot "story.d"  using 1:            178
pause -1
set ylabel  "Orbital Z Parameter             176"
plot "story.d"  using 1:            179
pause -1
set ylabel  "Orbital Z Parameter             177"
plot "story.d"  using 1:            180
pause -1
set ylabel  "Orbital Z Parameter             178"
plot "story.d"  using 1:            181
pause -1
set ylabel  "Orbital Z Parameter             179"
plot "story.d"  using 1:            182
pause -1
set ylabel  "Orbital Z Parameter             180"
plot "story.d"  using 1:            183
pause -1
set ylabel  "Orbital Z Parameter             181"
plot "story.d"  using 1:            184
pause -1
set ylabel  "Orbital Z Parameter             182"
plot "story.d"  using 1:            185
pause -1
set ylabel  "Orbital Z Parameter             183"
plot "story.d"  using 1:            186
pause -1
set ylabel  "Orbital Z Parameter             184"
plot "story.d"  using 1:            187
pause -1
set ylabel  "Orbital Z Parameter             185"
plot "story.d"  using 1:            188
pause -1
set ylabel  "Orbital Z Parameter             186"
plot "story.d"  using 1:            189
pause -1
set ylabel  "Orbital Z Parameter             187"
plot "story.d"  using 1:            190
pause -1
set ylabel  "Orbital Z Parameter             188"
plot "story.d"  using 1:            191
pause -1
set ylabel  "Orbital Z Parameter             189"
plot "story.d"  using 1:            192
pause -1
set ylabel  "Orbital Z Parameter             190"
plot "story.d"  using 1:            193
pause -1
set ylabel  "Orbital Z Parameter             191"
plot "story.d"  using 1:            194
pause -1
set ylabel  "Orbital Z Parameter             192"
plot "story.d"  using 1:            195
pause -1
set ylabel  "Orbital Z Parameter             193"
plot "story.d"  using 1:            196
pause -1
set ylabel  "Orbital Z Parameter             194"
plot "story.d"  using 1:            197
pause -1
set ylabel  "Orbital Z Parameter             195"
plot "story.d"  using 1:            198
pause -1
set ylabel "Three Body Parameter Matrix               1"
plot "story.d"  using 1:            199
pause -1
set ylabel "Three Body Parameter Matrix               2"
plot "story.d"  using 1:            200
pause -1
set ylabel "Three Body Parameter Matrix               3"
plot "story.d"  using 1:            201
pause -1
set ylabel "Three Body Parameter Matrix               4"
plot "story.d"  using 1:            202
pause -1
set ylabel "Three Body Parameter Matrix               5"
plot "story.d"  using 1:            203
pause -1
set ylabel "Three Body Parameter Matrix               6"
plot "story.d"  using 1:            204
pause -1
set ylabel "Three Body Parameter Matrix               7"
plot "story.d"  using 1:            205
pause -1
set ylabel "Three Body Parameter Matrix               8"
plot "story.d"  using 1:            206
pause -1
set ylabel "Three Body Parameter Matrix               9"
plot "story.d"  using 1:            207
pause -1
set ylabel "Three Body Parameter Matrix              10"
plot "story.d"  using 1:            208
pause -1
set ylabel "Three Body Parameter Matrix              11"
plot "story.d"  using 1:            209
pause -1
set ylabel "Three Body Parameter Matrix              12"
plot "story.d"  using 1:            210
pause -1
set ylabel "Three Body Parameter Matrix              13"
plot "story.d"  using 1:            211
pause -1
set ylabel "Three Body Parameter Matrix              14"
plot "story.d"  using 1:            212
pause -1
set ylabel "Three Body Parameter Matrix              15"
plot "story.d"  using 1:            213
pause -1
set ylabel "Three Body Parameter Matrix              16"
plot "story.d"  using 1:            214
pause -1
set ylabel "Three Body Parameter Matrix              17"
plot "story.d"  using 1:            215
pause -1
set ylabel "Three Body Parameter Matrix              18"
plot "story.d"  using 1:            216
pause -1
set ylabel "Three Body Parameter Matrix              19"
plot "story.d"  using 1:            217
pause -1
set ylabel "Three Body Parameter Matrix              20"
plot "story.d"  using 1:            218
pause -1
set ylabel "Three Body Parameter Matrix              21"
plot "story.d"  using 1:            219
pause -1
set ylabel "Three Body Parameter Matrix              22"
plot "story.d"  using 1:            220
pause -1
set ylabel "Three Body Parameter Matrix              23"
plot "story.d"  using 1:            221
pause -1
set ylabel "Three Body Parameter Matrix              24"
plot "story.d"  using 1:            222
pause -1
set ylabel "Three Body Parameter Matrix              25"
plot "story.d"  using 1:            223
pause -1
set ylabel "Three Body Parameter Matrix              26"
plot "story.d"  using 1:            224
pause -1
set ylabel "Three Body Parameter Matrix              27"
plot "story.d"  using 1:            225
pause -1
set ylabel "Three Body Parameter Matrix              28"
plot "story.d"  using 1:            226
pause -1
set ylabel "Three Body Parameter Matrix              29"
plot "story.d"  using 1:            227
pause -1
set ylabel "Three Body Parameter Matrix              30"
plot "story.d"  using 1:            228
pause -1
set ylabel "Three Body Parameter Matrix              31"
plot "story.d"  using 1:            229
pause -1
set ylabel "Three Body Parameter Matrix              32"
plot "story.d"  using 1:            230
pause -1
set ylabel "Three Body Parameter Matrix              33"
plot "story.d"  using 1:            231
pause -1
set ylabel "Three Body Parameter Matrix              34"
plot "story.d"  using 1:            232
pause -1
set ylabel "Three Body Parameter Matrix              35"
plot "story.d"  using 1:            233
pause -1
set ylabel "Three Body Parameter Matrix              36"
plot "story.d"  using 1:            234
pause -1
set ylabel "Three Body Parameter Matrix              37"
plot "story.d"  using 1:            235
pause -1
set ylabel "Three Body Parameter Matrix              38"
plot "story.d"  using 1:            236
pause -1
set ylabel "Three Body Parameter Matrix              39"
plot "story.d"  using 1:            237
pause -1
set ylabel "Three Body Parameter Matrix              40"
plot "story.d"  using 1:            238
pause -1
set ylabel "Three Body Parameter Matrix              41"
plot "story.d"  using 1:            239
pause -1
set ylabel "Three Body Parameter Matrix              42"
plot "story.d"  using 1:            240
pause -1
set ylabel "Three Body Parameter Matrix              43"
plot "story.d"  using 1:            241
pause -1
set ylabel "Three Body Parameter Matrix              44"
plot "story.d"  using 1:            242
pause -1
set ylabel "Three Body Parameter Matrix              45"
plot "story.d"  using 1:            243
pause -1
set ylabel "Three Body Parameter Matrix              46"
plot "story.d"  using 1:            244
pause -1
set ylabel "Three Body Parameter Matrix              47"
plot "story.d"  using 1:            245
pause -1
set ylabel "Three Body Parameter Matrix              48"
plot "story.d"  using 1:            246
pause -1
set ylabel "Three Body Parameter Matrix              49"
plot "story.d"  using 1:            247
pause -1
set ylabel "Three Body Parameter Matrix              50"
plot "story.d"  using 1:            248
pause -1
set ylabel "Three Body Parameter Matrix              51"
plot "story.d"  using 1:            249
pause -1
set ylabel "Three Body Parameter Matrix              52"
plot "story.d"  using 1:            250
pause -1
set ylabel "Three Body Parameter Matrix              53"
plot "story.d"  using 1:            251
pause -1
set ylabel "Three Body Parameter Matrix              54"
plot "story.d"  using 1:            252
pause -1
set ylabel "Three Body Parameter Matrix              55"
plot "story.d"  using 1:            253
pause -1
set ylabel "Three Body Parameter Matrix              56"
plot "story.d"  using 1:            254
pause -1
set ylabel "Three Body Parameter Matrix              57"
plot "story.d"  using 1:            255
pause -1
set ylabel "Three Body Parameter Matrix              58"
plot "story.d"  using 1:            256
pause -1
set ylabel "Three Body Parameter Matrix              59"
plot "story.d"  using 1:            257
pause -1
set ylabel "Three Body Parameter Matrix              60"
plot "story.d"  using 1:            258
pause -1
set ylabel "Three Body Parameter Matrix              61"
plot "story.d"  using 1:            259
pause -1
set ylabel "Three Body Parameter Matrix              62"
plot "story.d"  using 1:            260
pause -1
set ylabel "Three Body Parameter Matrix              63"
plot "story.d"  using 1:            261
pause -1
set ylabel "Three Body Parameter Matrix              64"
plot "story.d"  using 1:            262
pause -1
set ylabel "Three Body Parameter Matrix              65"
plot "story.d"  using 1:            263
pause -1
set ylabel "Three Body Parameter Matrix              66"
plot "story.d"  using 1:            264
pause -1
set ylabel "Three Body Parameter Matrix              67"
plot "story.d"  using 1:            265
pause -1
set ylabel "Three Body Parameter Matrix              68"
plot "story.d"  using 1:            266
pause -1
set ylabel "Three Body Parameter Matrix              69"
plot "story.d"  using 1:            267
pause -1
set ylabel "Three Body Parameter Matrix              70"
plot "story.d"  using 1:            268
pause -1
set ylabel "Three Body Parameter Matrix              71"
plot "story.d"  using 1:            269
pause -1
set ylabel "Three Body Parameter Matrix              72"
plot "story.d"  using 1:            270
pause -1
set ylabel "Three Body Parameter Matrix              73"
plot "story.d"  using 1:            271
pause -1
set ylabel "Three Body Parameter Matrix              74"
plot "story.d"  using 1:            272
pause -1
set ylabel "Three Body Parameter Matrix              75"
plot "story.d"  using 1:            273
pause -1
set ylabel "Three Body Parameter Matrix              76"
plot "story.d"  using 1:            274
pause -1
set ylabel "Three Body Parameter Matrix              77"
plot "story.d"  using 1:            275
pause -1
set ylabel "Three Body Parameter Matrix              78"
plot "story.d"  using 1:            276
pause -1
set ylabel "Three Body Parameter Matrix              79"
plot "story.d"  using 1:            277
pause -1
set ylabel "Three Body Parameter Matrix              80"
plot "story.d"  using 1:            278
pause -1
set ylabel "Three Body Parameter Matrix              81"
plot "story.d"  using 1:            279
pause -1
set ylabel "Three Body Parameter Matrix              82"
plot "story.d"  using 1:            280
pause -1
set ylabel "Three Body Parameter Matrix              83"
plot "story.d"  using 1:            281
pause -1
set ylabel "Three Body Parameter Matrix              84"
plot "story.d"  using 1:            282
pause -1
set ylabel "Three Body Parameter Matrix              85"
plot "story.d"  using 1:            283
pause -1
set ylabel "Three Body Parameter Matrix              86"
plot "story.d"  using 1:            284
pause -1
set ylabel "Three Body Parameter Matrix              87"
plot "story.d"  using 1:            285
pause -1
set ylabel "Three Body Parameter Matrix              88"
plot "story.d"  using 1:            286
pause -1
set ylabel "Three Body Parameter Matrix              89"
plot "story.d"  using 1:            287
pause -1
set ylabel "Three Body Parameter Matrix              90"
plot "story.d"  using 1:            288
pause -1
set ylabel "Three Body Parameter Matrix              91"
plot "story.d"  using 1:            289
pause -1
set ylabel "Three Body Parameter Matrix              92"
plot "story.d"  using 1:            290
pause -1
set ylabel "Three Body Parameter Matrix              93"
plot "story.d"  using 1:            291
pause -1
set ylabel "Three Body Parameter Matrix              94"
plot "story.d"  using 1:            292
pause -1
set ylabel "Three Body Parameter Matrix              95"
plot "story.d"  using 1:            293
pause -1
set ylabel "Three Body Parameter Matrix              96"
plot "story.d"  using 1:            294
pause -1
set ylabel "Three Body Parameter Matrix              97"
plot "story.d"  using 1:            295
pause -1
set ylabel "Three Body Parameter Matrix              98"
plot "story.d"  using 1:            296
pause -1
set ylabel "Three Body Parameter Matrix              99"
plot "story.d"  using 1:            297
pause -1
set ylabel "Three Body Parameter Matrix             100"
plot "story.d"  using 1:            298
pause -1
set ylabel "Three Body Parameter Matrix             101"
plot "story.d"  using 1:            299
pause -1
set ylabel "Three Body Parameter Matrix             102"
plot "story.d"  using 1:            300
pause -1
set ylabel "Three Body Parameter Matrix             103"
plot "story.d"  using 1:            301
pause -1
set ylabel "Three Body Parameter Matrix             104"
plot "story.d"  using 1:            302
pause -1
set ylabel "Three Body Parameter Matrix             105"
plot "story.d"  using 1:            303
pause -1
set ylabel "Three Body Parameter Matrix             106"
plot "story.d"  using 1:            304
pause -1
set ylabel "Three Body Parameter Matrix             107"
plot "story.d"  using 1:            305
pause -1
set ylabel "Three Body Parameter Matrix             108"
plot "story.d"  using 1:            306
pause -1
set ylabel "Three Body Parameter Matrix             109"
plot "story.d"  using 1:            307
pause -1
set ylabel "Three Body Parameter Matrix             110"
plot "story.d"  using 1:            308
pause -1
set ylabel "Three Body Parameter Matrix             111"
plot "story.d"  using 1:            309
pause -1
set ylabel "Three Body Parameter Matrix             112"
plot "story.d"  using 1:            310
pause -1
set ylabel "Three Body Parameter Matrix             113"
plot "story.d"  using 1:            311
pause -1
set ylabel "Three Body Parameter Matrix             114"
plot "story.d"  using 1:            312
pause -1
set ylabel "Three Body Parameter Matrix             115"
plot "story.d"  using 1:            313
pause -1
set ylabel "Three Body Parameter Matrix             116"
plot "story.d"  using 1:            314
pause -1
set ylabel "Three Body Parameter Matrix             117"
plot "story.d"  using 1:            315
pause -1
set ylabel "Three Body Parameter Matrix             118"
plot "story.d"  using 1:            316
pause -1
set ylabel "Three Body Parameter Matrix             119"
plot "story.d"  using 1:            317
pause -1
set ylabel "Three Body Parameter Matrix             120"
plot "story.d"  using 1:            318
pause -1
set ylabel "Three Body Parameter Matrix             121"
plot "story.d"  using 1:            319
pause -1
set ylabel "Three Body Parameter Matrix             122"
plot "story.d"  using 1:            320
pause -1
set ylabel "Three Body Parameter Matrix             123"
plot "story.d"  using 1:            321
pause -1
set ylabel "Three Body Parameter Matrix             124"
plot "story.d"  using 1:            322
pause -1
set ylabel "Three Body Parameter Matrix             125"
plot "story.d"  using 1:            323
pause -1
set ylabel "Three Body Parameter Matrix             126"
plot "story.d"  using 1:            324
pause -1
set ylabel "Three Body Parameter Matrix             127"
plot "story.d"  using 1:            325
pause -1
set ylabel "Three Body Parameter Matrix             128"
plot "story.d"  using 1:            326
pause -1
set ylabel "Three Body Parameter Matrix             129"
plot "story.d"  using 1:            327
pause -1
set ylabel "Three Body Parameter Matrix             130"
plot "story.d"  using 1:            328
pause -1
set ylabel "Three Body Parameter Matrix             131"
plot "story.d"  using 1:            329
pause -1
set ylabel "Three Body Parameter Matrix             132"
plot "story.d"  using 1:            330
pause -1
set ylabel "Three Body Parameter Matrix             133"
plot "story.d"  using 1:            331
pause -1
set ylabel "Three Body Parameter Matrix             134"
plot "story.d"  using 1:            332
pause -1
set ylabel "Three Body Parameter Matrix             135"
plot "story.d"  using 1:            333
pause -1
set ylabel "Three Body Parameter Matrix             136"
plot "story.d"  using 1:            334
pause -1
set ylabel "Three Body Parameter Matrix             137"
plot "story.d"  using 1:            335
pause -1
set ylabel "Three Body Parameter Matrix             138"
plot "story.d"  using 1:            336
pause -1
set ylabel "Three Body Parameter Matrix             139"
plot "story.d"  using 1:            337
pause -1
set ylabel "Three Body Parameter Matrix             140"
plot "story.d"  using 1:            338
pause -1
set ylabel "Three Body Parameter Matrix             141"
plot "story.d"  using 1:            339
pause -1
set ylabel "Three Body Parameter Matrix             142"
plot "story.d"  using 1:            340
pause -1
set ylabel "Three Body Parameter Matrix             143"
plot "story.d"  using 1:            341
pause -1
set ylabel "Three Body Parameter Matrix             144"
plot "story.d"  using 1:            342
pause -1
set ylabel "Three Body Parameter Matrix             145"
plot "story.d"  using 1:            343
pause -1
set ylabel "Three Body Parameter Matrix             146"
plot "story.d"  using 1:            344
pause -1
set ylabel "Three Body Parameter Matrix             147"
plot "story.d"  using 1:            345
pause -1
set ylabel "Three Body Parameter Matrix             148"
plot "story.d"  using 1:            346
pause -1
set ylabel "Three Body Parameter Matrix             149"
plot "story.d"  using 1:            347
pause -1
set ylabel "Three Body Parameter Matrix             150"
plot "story.d"  using 1:            348
pause -1
set ylabel "Three Body Parameter Matrix             151"
plot "story.d"  using 1:            349
pause -1
set ylabel "Three Body Parameter Matrix             152"
plot "story.d"  using 1:            350
pause -1
set ylabel "Three Body Parameter Matrix             153"
plot "story.d"  using 1:            351
pause -1
set ylabel "Three Body Parameter Matrix             154"
plot "story.d"  using 1:            352
pause -1
set ylabel "Three Body Parameter Matrix             155"
plot "story.d"  using 1:            353
pause -1
set ylabel "Three Body Parameter Matrix             156"
plot "story.d"  using 1:            354
pause -1
set ylabel "Three Body Parameter Matrix             157"
plot "story.d"  using 1:            355
pause -1
set ylabel "Three Body Parameter Matrix             158"
plot "story.d"  using 1:            356
pause -1
set ylabel "Three Body Parameter Matrix             159"
plot "story.d"  using 1:            357
pause -1
set ylabel "Three Body Parameter Matrix             160"
plot "story.d"  using 1:            358
pause -1
set ylabel "Three Body Parameter Matrix             161"
plot "story.d"  using 1:            359
pause -1
set ylabel "Three Body Parameter Matrix             162"
plot "story.d"  using 1:            360
pause -1
set ylabel "Three Body Parameter Matrix             163"
plot "story.d"  using 1:            361
pause -1
set ylabel "Three Body Parameter Matrix             164"
plot "story.d"  using 1:            362
pause -1
set ylabel "Three Body Parameter Matrix             165"
plot "story.d"  using 1:            363
pause -1
set ylabel "Three Body Parameter Matrix             166"
plot "story.d"  using 1:            364
pause -1
set ylabel "Three Body Parameter Matrix             167"
plot "story.d"  using 1:            365
pause -1
set ylabel "Three Body Parameter Matrix             168"
plot "story.d"  using 1:            366
pause -1
set ylabel "Three Body Parameter Matrix             169"
plot "story.d"  using 1:            367
pause -1
set ylabel "Three Body Parameter Matrix             170"
plot "story.d"  using 1:            368
pause -1
set ylabel "Three Body Parameter Matrix             171"
plot "story.d"  using 1:            369
pause -1
set ylabel "Three Body Parameter Matrix             172"
plot "story.d"  using 1:            370
pause -1
set ylabel "Three Body Parameter Matrix             173"
plot "story.d"  using 1:            371
pause -1
set ylabel "Three Body Parameter Matrix             174"
plot "story.d"  using 1:            372
pause -1
set ylabel "Three Body Parameter Matrix             175"
plot "story.d"  using 1:            373
pause -1
set ylabel "Three Body Parameter Matrix             176"
plot "story.d"  using 1:            374
pause -1
set ylabel "Three Body Parameter Matrix             177"
plot "story.d"  using 1:            375
pause -1
set ylabel "Three Body Parameter Matrix             178"
plot "story.d"  using 1:            376
pause -1
set ylabel "Three Body Parameter Matrix             179"
plot "story.d"  using 1:            377
pause -1
set ylabel "Three Body Parameter Matrix             180"
plot "story.d"  using 1:            378
pause -1
set ylabel "Three Body Parameter Matrix             181"
plot "story.d"  using 1:            379
pause -1
set ylabel "Three Body Parameter Matrix             182"
plot "story.d"  using 1:            380
pause -1
set ylabel "Three Body Parameter Matrix             183"
plot "story.d"  using 1:            381
pause -1
set ylabel "Three Body Parameter Matrix             184"
plot "story.d"  using 1:            382
pause -1
set ylabel "Three Body Parameter Matrix             185"
plot "story.d"  using 1:            383
pause -1
set ylabel "Three Body Parameter Matrix             186"
plot "story.d"  using 1:            384
pause -1
set ylabel "Three Body Parameter Matrix             187"
plot "story.d"  using 1:            385
pause -1
set ylabel "Three Body Parameter Matrix             188"
plot "story.d"  using 1:            386
pause -1
set ylabel "Three Body Parameter Matrix             189"
plot "story.d"  using 1:            387
pause -1
set ylabel "Three Body Parameter Matrix             190"
plot "story.d"  using 1:            388
pause -1
set ylabel "Three Body Parameter Matrix             191"
plot "story.d"  using 1:            389
pause -1
set ylabel "Three Body Parameter Matrix             192"
plot "story.d"  using 1:            390
pause -1
set ylabel "Three Body Parameter Matrix             193"
plot "story.d"  using 1:            391
pause -1
set ylabel "Three Body Parameter Matrix             194"
plot "story.d"  using 1:            392
pause -1
set ylabel "Three Body Parameter Matrix             195"
plot "story.d"  using 1:            393
pause -1
set ylabel "Three Body Parameter Matrix             196"
plot "story.d"  using 1:            394
pause -1
set ylabel "Three Body Parameter Matrix             197"
plot "story.d"  using 1:            395
pause -1
set ylabel "Three Body Parameter Matrix             198"
plot "story.d"  using 1:            396
pause -1
set ylabel "Three Body Parameter Matrix             199"
plot "story.d"  using 1:            397
pause -1
set ylabel "Three Body Parameter Matrix             200"
plot "story.d"  using 1:            398
pause -1
set ylabel "Three Body Parameter Matrix             201"
plot "story.d"  using 1:            399
pause -1
set ylabel "Three Body Parameter Matrix             202"
plot "story.d"  using 1:            400
pause -1
set ylabel "Three Body Parameter Matrix             203"
plot "story.d"  using 1:            401
pause -1
set ylabel "Three Body Parameter Matrix             204"
plot "story.d"  using 1:            402
pause -1
set ylabel "Three Body Parameter Matrix             205"
plot "story.d"  using 1:            403
pause -1
set ylabel "Three Body Parameter Matrix             206"
plot "story.d"  using 1:            404
pause -1
set ylabel "Three Body Parameter Matrix             207"
plot "story.d"  using 1:            405
pause -1
set ylabel "Three Body Parameter Matrix             208"
plot "story.d"  using 1:            406
pause -1
set ylabel "Three Body Parameter Matrix             209"
plot "story.d"  using 1:            407
pause -1
set ylabel "Three Body Parameter Matrix             210"
plot "story.d"  using 1:            408
pause -1
set ylabel "Three Body Parameter Matrix             211"
plot "story.d"  using 1:            409
pause -1
set ylabel "Three Body Parameter Matrix             212"
plot "story.d"  using 1:            410
pause -1
set ylabel "Three Body Parameter Matrix             213"
plot "story.d"  using 1:            411
pause -1
set ylabel "Three Body Parameter Matrix             214"
plot "story.d"  using 1:            412
pause -1
set ylabel "Three Body Parameter Matrix             215"
plot "story.d"  using 1:            413
pause -1
set ylabel "Three Body Parameter Matrix             216"
plot "story.d"  using 1:            414
pause -1
set ylabel "Three Body Parameter Matrix             217"
plot "story.d"  using 1:            415
pause -1
set ylabel "Three Body Parameter Matrix             218"
plot "story.d"  using 1:            416
pause -1
set ylabel "Three Body Parameter Matrix             219"
plot "story.d"  using 1:            417
pause -1
set ylabel "Three Body Parameter Matrix             220"
plot "story.d"  using 1:            418
pause -1
set ylabel "Three Body Parameter Matrix             221"
plot "story.d"  using 1:            419
pause -1
set ylabel "Three Body Parameter Matrix             222"
plot "story.d"  using 1:            420
pause -1
set ylabel "Three Body Parameter Matrix             223"
plot "story.d"  using 1:            421
pause -1
set ylabel "Three Body Parameter Matrix             224"
plot "story.d"  using 1:            422
pause -1
set ylabel "Three Body Parameter Matrix             225"
plot "story.d"  using 1:            423
pause -1
set ylabel "Three Body Parameter Matrix             226"
plot "story.d"  using 1:            424
pause -1
set ylabel "Three Body Parameter Matrix             227"
plot "story.d"  using 1:            425
pause -1
set ylabel "Three Body Parameter Matrix             228"
plot "story.d"  using 1:            426
pause -1
set ylabel "Three Body Parameter Matrix             229"
plot "story.d"  using 1:            427
pause -1
set ylabel "Three Body Parameter Matrix             230"
plot "story.d"  using 1:            428
pause -1
set ylabel "Three Body Parameter Matrix             231"
plot "story.d"  using 1:            429
pause -1
set ylabel "Three Body Parameter Matrix             232"
plot "story.d"  using 1:            430
pause -1
set ylabel "Three Body Parameter Matrix             233"
plot "story.d"  using 1:            431
pause -1
set ylabel "Three Body Parameter Matrix             234"
plot "story.d"  using 1:            432
pause -1
set ylabel "Three Body Parameter Matrix             235"
plot "story.d"  using 1:            433
pause -1
set ylabel "Three Body Parameter Matrix             236"
plot "story.d"  using 1:            434
pause -1
set ylabel "Three Body Parameter Matrix             237"
plot "story.d"  using 1:            435
pause -1
set ylabel "Three Body Parameter Matrix             238"
plot "story.d"  using 1:            436
pause -1
set ylabel "Three Body Parameter Matrix             239"
plot "story.d"  using 1:            437
pause -1
set ylabel "Three Body Parameter Matrix             240"
plot "story.d"  using 1:            438
pause -1
set ylabel "Three Body Parameter Matrix             241"
plot "story.d"  using 1:            439
pause -1
set ylabel "Three Body Parameter Matrix             242"
plot "story.d"  using 1:            440
pause -1
set ylabel "Three Body Parameter Matrix             243"
plot "story.d"  using 1:            441
pause -1
set ylabel "Three Body Parameter Matrix             244"
plot "story.d"  using 1:            442
pause -1
set ylabel "Three Body Parameter Matrix             245"
plot "story.d"  using 1:            443
pause -1
set ylabel "Three Body Parameter Matrix             246"
plot "story.d"  using 1:            444
pause -1
set ylabel "Three Body Parameter Matrix             247"
plot "story.d"  using 1:            445
pause -1
set ylabel "Three Body Parameter Matrix             248"
plot "story.d"  using 1:            446
pause -1
set ylabel "Three Body Parameter Matrix             249"
plot "story.d"  using 1:            447
pause -1
set ylabel "Three Body Parameter Matrix             250"
plot "story.d"  using 1:            448
pause -1
set ylabel "Three Body Parameter Matrix             251"
plot "story.d"  using 1:            449
pause -1
set ylabel "Three Body Parameter Matrix             252"
plot "story.d"  using 1:            450
pause -1
set ylabel "Three Body Parameter Matrix             253"
plot "story.d"  using 1:            451
pause -1
set ylabel "Three Body Parameter Matrix             254"
plot "story.d"  using 1:            452
pause -1
set ylabel "Three Body Parameter Matrix             255"
plot "story.d"  using 1:            453
pause -1
set ylabel "Three Body Parameter Matrix             256"
plot "story.d"  using 1:            454
pause -1
set ylabel "Three Body Parameter Matrix             257"
plot "story.d"  using 1:            455
pause -1
set ylabel "Three Body Parameter Matrix             258"
plot "story.d"  using 1:            456
pause -1
set ylabel "Three Body Parameter Matrix             259"
plot "story.d"  using 1:            457
pause -1
set ylabel "Three Body Parameter Matrix             260"
plot "story.d"  using 1:            458
pause -1
set ylabel "Three Body Parameter Matrix             261"
plot "story.d"  using 1:            459
pause -1
set ylabel "Three Body Parameter Matrix             262"
plot "story.d"  using 1:            460
pause -1
set ylabel "Three Body Parameter Matrix             263"
plot "story.d"  using 1:            461
pause -1
set ylabel "Three Body Parameter Matrix             264"
plot "story.d"  using 1:            462
pause -1
set ylabel "Three Body Parameter Matrix             265"
plot "story.d"  using 1:            463
pause -1
set ylabel "Three Body Parameter Matrix             266"
plot "story.d"  using 1:            464
pause -1
set ylabel "Three Body Parameter Matrix             267"
plot "story.d"  using 1:            465
pause -1
set ylabel "Three Body Parameter Matrix             268"
plot "story.d"  using 1:            466
pause -1
set ylabel "Three Body Parameter Matrix             269"
plot "story.d"  using 1:            467
pause -1
set ylabel "Three Body Parameter Matrix             270"
plot "story.d"  using 1:            468
pause -1
set ylabel "Three Body Parameter Matrix             271"
plot "story.d"  using 1:            469
pause -1
set ylabel "Three Body Parameter Matrix             272"
plot "story.d"  using 1:            470
pause -1
set ylabel "Three Body Parameter Matrix             273"
plot "story.d"  using 1:            471
pause -1
set ylabel "Three Body Parameter Matrix             274"
plot "story.d"  using 1:            472
pause -1
set ylabel "Three Body Parameter Matrix             275"
plot "story.d"  using 1:            473
pause -1
set ylabel "Three Body Parameter Matrix             276"
plot "story.d"  using 1:            474
pause -1
set ylabel "Three Body Parameter Matrix             277"
plot "story.d"  using 1:            475
pause -1
set ylabel "Three Body Parameter Matrix             278"
plot "story.d"  using 1:            476
pause -1
set ylabel "Three Body Parameter Matrix             279"
plot "story.d"  using 1:            477
pause -1
set ylabel "Three Body Parameter Matrix             280"
plot "story.d"  using 1:            478
pause -1
set ylabel "Three Body Parameter Matrix             281"
plot "story.d"  using 1:            479
pause -1
set ylabel "Three Body Parameter Matrix             282"
plot "story.d"  using 1:            480
pause -1
set ylabel "Three Body Parameter Matrix             283"
plot "story.d"  using 1:            481
pause -1
set ylabel "Three Body Parameter Matrix             284"
plot "story.d"  using 1:            482
pause -1
set ylabel "Three Body Parameter Matrix             285"
plot "story.d"  using 1:            483
pause -1
set ylabel "Three Body Parameter Matrix             286"
plot "story.d"  using 1:            484
pause -1
set ylabel "Three Body Parameter Matrix             287"
plot "story.d"  using 1:            485
pause -1
set ylabel "Three Body Parameter Matrix             288"
plot "story.d"  using 1:            486
pause -1
set ylabel "Three Body Parameter Matrix             289"
plot "story.d"  using 1:            487
pause -1
set ylabel "Three Body Parameter Matrix             290"
plot "story.d"  using 1:            488
pause -1
set ylabel "Three Body Parameter Matrix             291"
plot "story.d"  using 1:            489
pause -1
set ylabel "Three Body Parameter Matrix             292"
plot "story.d"  using 1:            490
pause -1
set ylabel "Three Body Parameter Matrix             293"
plot "story.d"  using 1:            491
pause -1
set ylabel "Three Body Parameter Matrix             294"
plot "story.d"  using 1:            492
pause -1
set ylabel "Three Body Parameter Matrix             295"
plot "story.d"  using 1:            493
pause -1
set ylabel "Three Body Parameter Matrix             296"
plot "story.d"  using 1:            494
pause -1
set ylabel "Three Body Parameter Matrix             297"
plot "story.d"  using 1:            495
pause -1
set ylabel "Three Body Parameter Matrix             298"
plot "story.d"  using 1:            496
pause -1
set ylabel "Three Body Parameter Matrix             299"
plot "story.d"  using 1:            497
pause -1
set ylabel "Three Body Parameter Matrix             300"
plot "story.d"  using 1:            498
pause -1
set ylabel "Three Body Parameter Matrix             301"
plot "story.d"  using 1:            499
pause -1
set ylabel "Three Body Parameter Matrix             302"
plot "story.d"  using 1:            500
pause -1
set ylabel "Three Body Parameter Matrix             303"
plot "story.d"  using 1:            501
pause -1
set ylabel "Three Body Parameter Matrix             304"
plot "story.d"  using 1:            502
pause -1
set ylabel "Three Body Parameter Matrix             305"
plot "story.d"  using 1:            503
pause -1
set ylabel "Three Body Parameter Matrix             306"
plot "story.d"  using 1:            504
pause -1
set ylabel "Three Body Parameter Matrix             307"
plot "story.d"  using 1:            505
pause -1
set ylabel "Three Body Parameter Matrix             308"
plot "story.d"  using 1:            506
pause -1
set ylabel "Three Body Parameter Matrix             309"
plot "story.d"  using 1:            507
pause -1
set ylabel "Three Body Parameter Matrix             310"
plot "story.d"  using 1:            508
pause -1
set ylabel "Three Body Parameter Matrix             311"
plot "story.d"  using 1:            509
pause -1
set ylabel "Three Body Parameter Matrix             312"
plot "story.d"  using 1:            510
pause -1
set ylabel "Three Body Parameter Matrix             313"
plot "story.d"  using 1:            511
pause -1
set ylabel "Three Body Parameter Matrix             314"
plot "story.d"  using 1:            512
pause -1
set ylabel "Three Body Parameter Matrix             315"
plot "story.d"  using 1:            513
pause -1
set ylabel "Three Body Parameter Matrix             316"
plot "story.d"  using 1:            514
pause -1
set ylabel "Three Body Parameter Matrix             317"
plot "story.d"  using 1:            515
pause -1
set ylabel "Three Body Parameter Matrix             318"
plot "story.d"  using 1:            516
pause -1
set ylabel "Three Body Parameter Matrix             319"
plot "story.d"  using 1:            517
pause -1
set ylabel "Three Body Parameter Matrix             320"
plot "story.d"  using 1:            518
pause -1
set ylabel "Three Body Parameter Matrix             321"
plot "story.d"  using 1:            519
pause -1
set ylabel "Three Body Parameter Matrix             322"
plot "story.d"  using 1:            520
pause -1
set ylabel "Three Body Parameter Matrix             323"
plot "story.d"  using 1:            521
pause -1
set ylabel "Three Body Parameter Matrix             324"
plot "story.d"  using 1:            522
pause -1
set ylabel "Three Body Parameter Matrix             325"
plot "story.d"  using 1:            523
pause -1
set ylabel "Three Body Parameter Matrix             326"
plot "story.d"  using 1:            524
pause -1
set ylabel "Three Body Parameter Matrix             327"
plot "story.d"  using 1:            525
pause -1
set ylabel "Three Body Parameter Matrix             328"
plot "story.d"  using 1:            526
pause -1
set ylabel "Three Body Parameter Matrix             329"
plot "story.d"  using 1:            527
pause -1
set ylabel "Three Body Parameter Matrix             330"
plot "story.d"  using 1:            528
pause -1
set ylabel "Three Body Parameter Matrix             331"
plot "story.d"  using 1:            529
pause -1
set ylabel "Three Body Parameter Matrix             332"
plot "story.d"  using 1:            530
pause -1
set ylabel "Three Body Parameter Matrix             333"
plot "story.d"  using 1:            531
pause -1
set ylabel "Three Body Parameter Matrix             334"
plot "story.d"  using 1:            532
pause -1
set ylabel "Three Body Parameter Matrix             335"
plot "story.d"  using 1:            533
pause -1
set ylabel "Three Body Parameter Matrix             336"
plot "story.d"  using 1:            534
pause -1
set ylabel "Three Body Parameter Matrix             337"
plot "story.d"  using 1:            535
pause -1
set ylabel "Three Body Parameter Matrix             338"
plot "story.d"  using 1:            536
pause -1
set ylabel "Three Body Parameter Matrix             339"
plot "story.d"  using 1:            537
pause -1
set ylabel "Three Body Parameter Matrix             340"
plot "story.d"  using 1:            538
pause -1
set ylabel "Three Body Parameter Matrix             341"
plot "story.d"  using 1:            539
pause -1
set ylabel "Three Body Parameter Matrix             342"
plot "story.d"  using 1:            540
pause -1
set ylabel "Three Body Parameter Matrix             343"
plot "story.d"  using 1:            541
pause -1
set ylabel "Three Body Parameter Matrix             344"
plot "story.d"  using 1:            542
pause -1
set ylabel "Three Body Parameter Matrix             345"
plot "story.d"  using 1:            543
pause -1
set ylabel "Three Body Parameter Matrix             346"
plot "story.d"  using 1:            544
pause -1
set ylabel "Three Body Parameter Matrix             347"
plot "story.d"  using 1:            545
pause -1
set ylabel "Three Body Parameter Matrix             348"
plot "story.d"  using 1:            546
pause -1
set ylabel "Three Body Parameter Matrix             349"
plot "story.d"  using 1:            547
pause -1
set ylabel "Three Body Parameter Matrix             350"
plot "story.d"  using 1:            548
pause -1
set ylabel "Three Body Parameter Matrix             351"
plot "story.d"  using 1:            549
pause -1
set ylabel "Three Body Parameter Matrix             352"
plot "story.d"  using 1:            550
pause -1
set ylabel "Three Body Parameter Matrix             353"
plot "story.d"  using 1:            551
pause -1
set ylabel "Three Body Parameter Matrix             354"
plot "story.d"  using 1:            552
pause -1
set ylabel "Three Body Parameter Matrix             355"
plot "story.d"  using 1:            553
pause -1
set ylabel "Three Body Parameter Matrix             356"
plot "story.d"  using 1:            554
pause -1
set ylabel "Three Body Parameter Matrix             357"
plot "story.d"  using 1:            555
pause -1
set ylabel "Three Body Parameter Matrix             358"
plot "story.d"  using 1:            556
pause -1
set ylabel "Three Body Parameter Matrix             359"
plot "story.d"  using 1:            557
pause -1
set ylabel "Three Body Parameter Matrix             360"
plot "story.d"  using 1:            558
pause -1
set ylabel "Three Body Parameter Matrix             361"
plot "story.d"  using 1:            559
pause -1
set ylabel "Three Body Parameter Matrix             362"
plot "story.d"  using 1:            560
pause -1
set ylabel "Three Body Parameter Matrix             363"
plot "story.d"  using 1:            561
pause -1
set ylabel "Three Body Parameter Matrix             364"
plot "story.d"  using 1:            562
pause -1
set ylabel "Three Body Parameter Matrix             365"
plot "story.d"  using 1:            563
pause -1
set ylabel "Three Body Parameter Matrix             366"
plot "story.d"  using 1:            564
pause -1
set ylabel "Three Body Parameter Matrix             367"
plot "story.d"  using 1:            565
pause -1
set ylabel "Three Body Parameter Matrix             368"
plot "story.d"  using 1:            566
pause -1
set ylabel "Three Body Parameter Matrix             369"
plot "story.d"  using 1:            567
pause -1
set ylabel "Three Body Parameter Matrix             370"
plot "story.d"  using 1:            568
pause -1
set ylabel "Three Body Parameter Matrix             371"
plot "story.d"  using 1:            569
pause -1
set ylabel "Three Body Parameter Matrix             372"
plot "story.d"  using 1:            570
pause -1
set ylabel "Three Body Parameter Matrix             373"
plot "story.d"  using 1:            571
pause -1
set ylabel "Three Body Parameter Matrix             374"
plot "story.d"  using 1:            572
pause -1
set ylabel "Three Body Parameter Matrix             375"
plot "story.d"  using 1:            573
pause -1
set ylabel "Three Body Parameter Matrix             376"
plot "story.d"  using 1:            574
pause -1
set ylabel "Three Body Parameter Matrix             377"
plot "story.d"  using 1:            575
pause -1
set ylabel "Three Body Parameter Matrix             378"
plot "story.d"  using 1:            576
pause -1
set ylabel "Three Body Parameter Matrix             379"
plot "story.d"  using 1:            577
pause -1
set ylabel "Three Body Parameter Matrix             380"
plot "story.d"  using 1:            578
pause -1
set ylabel "Three Body Parameter Matrix             381"
plot "story.d"  using 1:            579
pause -1
set ylabel "Three Body Parameter Matrix             382"
plot "story.d"  using 1:            580
pause -1
set ylabel "Three Body Parameter Matrix             383"
plot "story.d"  using 1:            581
pause -1
set ylabel "Three Body Parameter Matrix             384"
plot "story.d"  using 1:            582
pause -1
set ylabel "Three Body Parameter Matrix             385"
plot "story.d"  using 1:            583
pause -1
set ylabel "Three Body Parameter Matrix             386"
plot "story.d"  using 1:            584
pause -1
set ylabel "Three Body Parameter Matrix             387"
plot "story.d"  using 1:            585
pause -1
set ylabel "Three Body Parameter Matrix             388"
plot "story.d"  using 1:            586
pause -1
set ylabel "Three Body Parameter Matrix             389"
plot "story.d"  using 1:            587
pause -1
set ylabel "Three Body Parameter Matrix             390"
plot "story.d"  using 1:            588
pause -1
set ylabel "Three Body Parameter Matrix             391"
plot "story.d"  using 1:            589
pause -1
set ylabel "Three Body Parameter Matrix             392"
plot "story.d"  using 1:            590
pause -1
set ylabel "Three Body Parameter Matrix             393"
plot "story.d"  using 1:            591
pause -1
set ylabel "Three Body Parameter Matrix             394"
plot "story.d"  using 1:            592
pause -1
set ylabel "Three Body Parameter Matrix             395"
plot "story.d"  using 1:            593
pause -1
set ylabel "Three Body Parameter Matrix             396"
plot "story.d"  using 1:            594
pause -1
set ylabel "Three Body Parameter Matrix             397"
plot "story.d"  using 1:            595
pause -1
set ylabel "Three Body Parameter Matrix             398"
plot "story.d"  using 1:            596
pause -1
set ylabel "Three Body Parameter Matrix             399"
plot "story.d"  using 1:            597
pause -1
set ylabel "Three Body Parameter Matrix             400"
plot "story.d"  using 1:            598
pause -1
set ylabel "Three Body Parameter Matrix             401"
plot "story.d"  using 1:            599
pause -1
set ylabel "Three Body Parameter Matrix             402"
plot "story.d"  using 1:            600
pause -1
set ylabel "Three Body Parameter Matrix             403"
plot "story.d"  using 1:            601
pause -1
set ylabel "Three Body Parameter Matrix             404"
plot "story.d"  using 1:            602
pause -1
set ylabel "Three Body Parameter Matrix             405"
plot "story.d"  using 1:            603
pause -1
set ylabel "Three Body Parameter Matrix             406"
plot "story.d"  using 1:            604
pause -1
set ylabel "Three Body Parameter Matrix             407"
plot "story.d"  using 1:            605
pause -1
set ylabel "Three Body Parameter Matrix             408"
plot "story.d"  using 1:            606
pause -1
set ylabel "Three Body Parameter Matrix             409"
plot "story.d"  using 1:            607
pause -1
set ylabel "Three Body Parameter Matrix             410"
plot "story.d"  using 1:            608
pause -1
set ylabel "Three Body Parameter Matrix             411"
plot "story.d"  using 1:            609
pause -1
set ylabel "Three Body Parameter Matrix             412"
plot "story.d"  using 1:            610
pause -1
set ylabel "Three Body Parameter Matrix             413"
plot "story.d"  using 1:            611
pause -1
set ylabel "Three Body Parameter Matrix             414"
plot "story.d"  using 1:            612
pause -1
set ylabel "Three Body Parameter Matrix             415"
plot "story.d"  using 1:            613
pause -1
set ylabel "Three Body Parameter Matrix             416"
plot "story.d"  using 1:            614
pause -1
set ylabel "Three Body Parameter Matrix             417"
plot "story.d"  using 1:            615
pause -1
set ylabel "Three Body Parameter Matrix             418"
plot "story.d"  using 1:            616
pause -1
set ylabel "Three Body Parameter Matrix             419"
plot "story.d"  using 1:            617
pause -1
set ylabel "Three Body Parameter Matrix             420"
plot "story.d"  using 1:            618
pause -1
set ylabel "Three Body Parameter Matrix             421"
plot "story.d"  using 1:            619
pause -1
set ylabel "Three Body Parameter Matrix             422"
plot "story.d"  using 1:            620
pause -1
set ylabel "Three Body Parameter Matrix             423"
plot "story.d"  using 1:            621
pause -1
set ylabel "Three Body Parameter Matrix             424"
plot "story.d"  using 1:            622
pause -1
set ylabel "Three Body Parameter Matrix             425"
plot "story.d"  using 1:            623
pause -1
set ylabel "Three Body Parameter Matrix             426"
plot "story.d"  using 1:            624
pause -1
set ylabel "Three Body Parameter Matrix             427"
plot "story.d"  using 1:            625
pause -1
set ylabel "Three Body Parameter Matrix             428"
plot "story.d"  using 1:            626
pause -1
set ylabel "Three Body Parameter Matrix             429"
plot "story.d"  using 1:            627
pause -1
set ylabel "Three Body Parameter Matrix             430"
plot "story.d"  using 1:            628
pause -1
set ylabel "Three Body Parameter Matrix             431"
plot "story.d"  using 1:            629
pause -1
set ylabel "Three Body Parameter Matrix             432"
plot "story.d"  using 1:            630
pause -1
set ylabel "Three Body Parameter Matrix             433"
plot "story.d"  using 1:            631
pause -1
set ylabel "Three Body Parameter Matrix             434"
plot "story.d"  using 1:            632
pause -1
set ylabel "Three Body Parameter Matrix             435"
plot "story.d"  using 1:            633
pause -1
set ylabel "Three Body Parameter Matrix             436"
plot "story.d"  using 1:            634
pause -1
set ylabel "Three Body Parameter Matrix             437"
plot "story.d"  using 1:            635
pause -1
set ylabel "Three Body Parameter Matrix             438"
plot "story.d"  using 1:            636
pause -1
set ylabel "Three Body Parameter Matrix             439"
plot "story.d"  using 1:            637
pause -1
set ylabel "Three Body Parameter Matrix             440"
plot "story.d"  using 1:            638
pause -1
set ylabel "Three Body Parameter Matrix             441"
plot "story.d"  using 1:            639
pause -1
set ylabel "Three Body Parameter Matrix             442"
plot "story.d"  using 1:            640
pause -1
set ylabel "Three Body Parameter Matrix             443"
plot "story.d"  using 1:            641
pause -1
set ylabel "Three Body Parameter Matrix             444"
plot "story.d"  using 1:            642
pause -1
set ylabel "Three Body Parameter Matrix             445"
plot "story.d"  using 1:            643
pause -1
set ylabel "Three Body Parameter Matrix             446"
plot "story.d"  using 1:            644
pause -1
set ylabel "Three Body Parameter Matrix             447"
plot "story.d"  using 1:            645
pause -1
set ylabel "Three Body Parameter Matrix             448"
plot "story.d"  using 1:            646
pause -1
set ylabel "Three Body Parameter Matrix             449"
plot "story.d"  using 1:            647
pause -1
set ylabel "Three Body Parameter Matrix             450"
plot "story.d"  using 1:            648
pause -1
set ylabel "Three Body Parameter Matrix             451"
plot "story.d"  using 1:            649
pause -1
set ylabel "Three Body Parameter Matrix             452"
plot "story.d"  using 1:            650
pause -1
set ylabel "Three Body Parameter Matrix             453"
plot "story.d"  using 1:            651
pause -1
set ylabel "Three Body Parameter Matrix             454"
plot "story.d"  using 1:            652
pause -1
set ylabel "Three Body Parameter Matrix             455"
plot "story.d"  using 1:            653
pause -1
set ylabel "Three Body Parameter Matrix             456"
plot "story.d"  using 1:            654
pause -1
set ylabel "Three Body Parameter Matrix             457"
plot "story.d"  using 1:            655
pause -1
set ylabel "Three Body Parameter Matrix             458"
plot "story.d"  using 1:            656
pause -1
set ylabel "Three Body Parameter Matrix             459"
plot "story.d"  using 1:            657
pause -1
set ylabel "Three Body Parameter Matrix             460"
plot "story.d"  using 1:            658
pause -1
set ylabel "Three Body Parameter Matrix             461"
plot "story.d"  using 1:            659
pause -1
set ylabel "Three Body Parameter Matrix             462"
plot "story.d"  using 1:            660
pause -1
set ylabel "Three Body Parameter Matrix             463"
plot "story.d"  using 1:            661
pause -1
set ylabel "Three Body Parameter Matrix             464"
plot "story.d"  using 1:            662
pause -1
set ylabel "Three Body Parameter Matrix             465"
plot "story.d"  using 1:            663
pause -1
set ylabel "Three Body Parameter Matrix             466"
plot "story.d"  using 1:            664
pause -1
set ylabel "Three Body Parameter Matrix             467"
plot "story.d"  using 1:            665
pause -1
set ylabel "Three Body Parameter Matrix             468"
plot "story.d"  using 1:            666
pause -1
set ylabel "Three Body Parameter Matrix             469"
plot "story.d"  using 1:            667
pause -1
set ylabel "Three Body Parameter Matrix             470"
plot "story.d"  using 1:            668
pause -1
set ylabel "Three Body Parameter Matrix             471"
plot "story.d"  using 1:            669
pause -1
set ylabel "Three Body Parameter Matrix             472"
plot "story.d"  using 1:            670
pause -1
set ylabel "Three Body Parameter Matrix             473"
plot "story.d"  using 1:            671
pause -1
set ylabel "Three Body Parameter Matrix             474"
plot "story.d"  using 1:            672
pause -1
set ylabel "Three Body Parameter Matrix             475"
plot "story.d"  using 1:            673
pause -1
set ylabel "Three Body Parameter Matrix             476"
plot "story.d"  using 1:            674
pause -1
set ylabel "Three Body Parameter Matrix             477"
plot "story.d"  using 1:            675
pause -1
set ylabel "Three Body Parameter Matrix             478"
plot "story.d"  using 1:            676
pause -1
set ylabel "Three Body Parameter Matrix             479"
plot "story.d"  using 1:            677
pause -1
set ylabel "Three Body Parameter Matrix             480"
plot "story.d"  using 1:            678
pause -1
set ylabel "Three Body Parameter Matrix             481"
plot "story.d"  using 1:            679
pause -1
set ylabel "Three Body Parameter Matrix             482"
plot "story.d"  using 1:            680
pause -1
set ylabel "Three Body Parameter Matrix             483"
plot "story.d"  using 1:            681
pause -1
set ylabel "Three Body Parameter Matrix             484"
plot "story.d"  using 1:            682
pause -1
set ylabel "Three Body Parameter Matrix             485"
plot "story.d"  using 1:            683
pause -1
set ylabel "Three Body Parameter Matrix             486"
plot "story.d"  using 1:            684
pause -1
set ylabel "Three Body Parameter Matrix             487"
plot "story.d"  using 1:            685
pause -1
set ylabel "Three Body Parameter Matrix             488"
plot "story.d"  using 1:            686
pause -1
set ylabel "Three Body Parameter Matrix             489"
plot "story.d"  using 1:            687
pause -1
set ylabel "Three Body Parameter Matrix             490"
plot "story.d"  using 1:            688
pause -1
set ylabel "Three Body Parameter Matrix             491"
plot "story.d"  using 1:            689
pause -1
set ylabel "Three Body Parameter Matrix             492"
plot "story.d"  using 1:            690
pause -1
set ylabel "Three Body Parameter Matrix             493"
plot "story.d"  using 1:            691
pause -1
set ylabel "Three Body Parameter Matrix             494"
plot "story.d"  using 1:            692
pause -1
set ylabel "Three Body Parameter Matrix             495"
plot "story.d"  using 1:            693
pause -1
set ylabel "Three Body Parameter Matrix             496"
plot "story.d"  using 1:            694
pause -1
set ylabel "Three Body Parameter Matrix             497"
plot "story.d"  using 1:            695
pause -1
set ylabel "Three Body Parameter Matrix             498"
plot "story.d"  using 1:            696
pause -1
set ylabel "Three Body Parameter Matrix             499"
plot "story.d"  using 1:            697
pause -1
set ylabel "Three Body Parameter Matrix             500"
plot "story.d"  using 1:            698
pause -1
set ylabel "Three Body Parameter Matrix             501"
plot "story.d"  using 1:            699
pause -1
set ylabel "Three Body Parameter Matrix             502"
plot "story.d"  using 1:            700
pause -1
set ylabel "Three Body Parameter Matrix             503"
plot "story.d"  using 1:            701
pause -1
set ylabel "Three Body Parameter Matrix             504"
plot "story.d"  using 1:            702
pause -1
set ylabel "Three Body Parameter Matrix             505"
plot "story.d"  using 1:            703
pause -1
set ylabel "Three Body Parameter Matrix             506"
plot "story.d"  using 1:            704
pause -1
set ylabel "Three Body Parameter Matrix             507"
plot "story.d"  using 1:            705
pause -1
set ylabel "Three Body Parameter Matrix             508"
plot "story.d"  using 1:            706
pause -1
set ylabel "Three Body Parameter Matrix             509"
plot "story.d"  using 1:            707
pause -1
set ylabel "Three Body Parameter Matrix             510"
plot "story.d"  using 1:            708
pause -1
set ylabel "Three Body Parameter Matrix             511"
plot "story.d"  using 1:            709
pause -1
set ylabel "Three Body Parameter Matrix             512"
plot "story.d"  using 1:            710
pause -1
set ylabel "Three Body Parameter Matrix             513"
plot "story.d"  using 1:            711
pause -1
set ylabel "Three Body Parameter Matrix             514"
plot "story.d"  using 1:            712
pause -1
set ylabel "Three Body Parameter Matrix             515"
plot "story.d"  using 1:            713
pause -1
set ylabel "Three Body Parameter Matrix             516"
plot "story.d"  using 1:            714
pause -1
set ylabel "Three Body Parameter Matrix             517"
plot "story.d"  using 1:            715
pause -1
set ylabel "Three Body Parameter Matrix             518"
plot "story.d"  using 1:            716
pause -1
set ylabel "Three Body Parameter Matrix             519"
plot "story.d"  using 1:            717
pause -1
set ylabel "Three Body Parameter Matrix             520"
plot "story.d"  using 1:            718
pause -1
set ylabel "Three Body Parameter Matrix             521"
plot "story.d"  using 1:            719
pause -1
set ylabel "Three Body Parameter Matrix             522"
plot "story.d"  using 1:            720
pause -1
set ylabel "Three Body Parameter Matrix             523"
plot "story.d"  using 1:            721
pause -1
set ylabel "Three Body Parameter Matrix             524"
plot "story.d"  using 1:            722
pause -1
set ylabel "Three Body Parameter Matrix             525"
plot "story.d"  using 1:            723
pause -1
set ylabel "Three Body Parameter Matrix             526"
plot "story.d"  using 1:            724
pause -1
set ylabel "Three Body Parameter Matrix             527"
plot "story.d"  using 1:            725
pause -1
set ylabel "Three Body Parameter Matrix             528"
plot "story.d"  using 1:            726
pause -1
set ylabel "Three Body Parameter Matrix             529"
plot "story.d"  using 1:            727
pause -1
set ylabel "Three Body Parameter Matrix             530"
plot "story.d"  using 1:            728
pause -1
set ylabel "Three Body Parameter Matrix             531"
plot "story.d"  using 1:            729
pause -1
set ylabel "Three Body Parameter Matrix             532"
plot "story.d"  using 1:            730
pause -1
set ylabel "Three Body Parameter Matrix             533"
plot "story.d"  using 1:            731
pause -1
set ylabel "Three Body Parameter Matrix             534"
plot "story.d"  using 1:            732
pause -1
set ylabel "Three Body Parameter Matrix             535"
plot "story.d"  using 1:            733
pause -1
set ylabel "Three Body Parameter Matrix             536"
plot "story.d"  using 1:            734
pause -1
set ylabel "Three Body Parameter Matrix             537"
plot "story.d"  using 1:            735
pause -1
set ylabel "Three Body Parameter Matrix             538"
plot "story.d"  using 1:            736
pause -1
set ylabel "Three Body Parameter Matrix             539"
plot "story.d"  using 1:            737
pause -1
set ylabel "Three Body Parameter Matrix             540"
plot "story.d"  using 1:            738
pause -1
set ylabel "Three Body Parameter Matrix             541"
plot "story.d"  using 1:            739
pause -1
set ylabel "Three Body Parameter Matrix             542"
plot "story.d"  using 1:            740
pause -1
set ylabel "Three Body Parameter Matrix             543"
plot "story.d"  using 1:            741
pause -1
set ylabel "Three Body Parameter Matrix             544"
plot "story.d"  using 1:            742
pause -1
set ylabel "Three Body Parameter Matrix             545"
plot "story.d"  using 1:            743
pause -1
set ylabel "Three Body Parameter Matrix             546"
plot "story.d"  using 1:            744
pause -1
set ylabel "Three Body Parameter Matrix             547"
plot "story.d"  using 1:            745
pause -1
set ylabel "Three Body Parameter Matrix             548"
plot "story.d"  using 1:            746
pause -1
set ylabel "Three Body Parameter Matrix             549"
plot "story.d"  using 1:            747
pause -1
set ylabel "Three Body Parameter Matrix             550"
plot "story.d"  using 1:            748
pause -1
set ylabel "Three Body Parameter Matrix             551"
plot "story.d"  using 1:            749
pause -1
set ylabel "Three Body Parameter Matrix             552"
plot "story.d"  using 1:            750
pause -1
set ylabel "Three Body Parameter Matrix             553"
plot "story.d"  using 1:            751
pause -1
set ylabel "Three Body Parameter Matrix             554"
plot "story.d"  using 1:            752
pause -1
set ylabel "Three Body Parameter Matrix             555"
plot "story.d"  using 1:            753
pause -1
set ylabel "Three Body Parameter Matrix             556"
plot "story.d"  using 1:            754
pause -1
set ylabel "Three Body Parameter Matrix             557"
plot "story.d"  using 1:            755
pause -1
set ylabel "Three Body Parameter Matrix             558"
plot "story.d"  using 1:            756
pause -1
set ylabel "Three Body Parameter Matrix             559"
plot "story.d"  using 1:            757
pause -1
set ylabel "Three Body Parameter Matrix             560"
plot "story.d"  using 1:            758
pause -1
set ylabel "Three Body Parameter Matrix             561"
plot "story.d"  using 1:            759
pause -1
set ylabel "Three Body Parameter Matrix             562"
plot "story.d"  using 1:            760
pause -1
set ylabel "Three Body Parameter Matrix             563"
plot "story.d"  using 1:            761
pause -1
set ylabel "Three Body Parameter Matrix             564"
plot "story.d"  using 1:            762
pause -1
set ylabel "Three Body Parameter Matrix             565"
plot "story.d"  using 1:            763
pause -1
set ylabel "Three Body Parameter Matrix             566"
plot "story.d"  using 1:            764
pause -1
set ylabel "Three Body Parameter Matrix             567"
plot "story.d"  using 1:            765
pause -1
set ylabel "Three Body Parameter Matrix             568"
plot "story.d"  using 1:            766
pause -1
set ylabel "Three Body Parameter Matrix             569"
plot "story.d"  using 1:            767
pause -1
set ylabel "Three Body Parameter Matrix             570"
plot "story.d"  using 1:            768
pause -1
set ylabel "Three Body Parameter Matrix             571"
plot "story.d"  using 1:            769
pause -1
set ylabel "Three Body Parameter Matrix             572"
plot "story.d"  using 1:            770
pause -1
set ylabel "Three Body Parameter Matrix             573"
plot "story.d"  using 1:            771
pause -1
set ylabel "Three Body Parameter Matrix             574"
plot "story.d"  using 1:            772
pause -1
set ylabel "Three Body Parameter Matrix             575"
plot "story.d"  using 1:            773
pause -1
set ylabel "Three Body Parameter Matrix             576"
plot "story.d"  using 1:            774
pause -1
set ylabel "Three Body Parameter Matrix             577"
plot "story.d"  using 1:            775
pause -1
set ylabel "Three Body Parameter Matrix             578"
plot "story.d"  using 1:            776
pause -1
set ylabel "Three Body Parameter Matrix             579"
plot "story.d"  using 1:            777
pause -1
set ylabel "Three Body Parameter Matrix             580"
plot "story.d"  using 1:            778
pause -1
set ylabel "Three Body Parameter Matrix             581"
plot "story.d"  using 1:            779
pause -1
set ylabel "Three Body Parameter Matrix             582"
plot "story.d"  using 1:            780
pause -1
set ylabel "Three Body Parameter Matrix             583"
plot "story.d"  using 1:            781
pause -1
set ylabel "Three Body Parameter Matrix             584"
plot "story.d"  using 1:            782
pause -1
set ylabel "Three Body Parameter Matrix             585"
plot "story.d"  using 1:            783
pause -1
set ylabel "Three Body Parameter Matrix             586"
plot "story.d"  using 1:            784
pause -1
set ylabel "Three Body Parameter Matrix             587"
plot "story.d"  using 1:            785
pause -1
set ylabel "Three Body Parameter Matrix             588"
plot "story.d"  using 1:            786
pause -1
set ylabel "Three Body Parameter Matrix             589"
plot "story.d"  using 1:            787
pause -1
set ylabel "Three Body Parameter Matrix             590"
plot "story.d"  using 1:            788
pause -1
set ylabel "Three Body Parameter Matrix             591"
plot "story.d"  using 1:            789
pause -1
set ylabel "Three Body Parameter Matrix             592"
plot "story.d"  using 1:            790
pause -1
set ylabel "Three Body Parameter Matrix             593"
plot "story.d"  using 1:            791
pause -1
set ylabel "Three Body Parameter Matrix             594"
plot "story.d"  using 1:            792
pause -1
set ylabel "Three Body Parameter Matrix             595"
plot "story.d"  using 1:            793
pause -1
set ylabel "Three Body Parameter Matrix             596"
plot "story.d"  using 1:            794
pause -1
set ylabel "Three Body Parameter Matrix             597"
plot "story.d"  using 1:            795
pause -1
set ylabel "Three Body Parameter Matrix             598"
plot "story.d"  using 1:            796
pause -1
set ylabel "Three Body Parameter Matrix             599"
plot "story.d"  using 1:            797
pause -1
set ylabel "Three Body Parameter Matrix             600"
plot "story.d"  using 1:            798
pause -1
set ylabel "Three Body Parameter Matrix             601"
plot "story.d"  using 1:            799
pause -1
set ylabel "Three Body Parameter Matrix             602"
plot "story.d"  using 1:            800
pause -1
set ylabel "Three Body Parameter Matrix             603"
plot "story.d"  using 1:            801
pause -1
set ylabel "Three Body Parameter Matrix             604"
plot "story.d"  using 1:            802
pause -1
set ylabel "Three Body Parameter Matrix             605"
plot "story.d"  using 1:            803
pause -1
set ylabel "Three Body Parameter Matrix             606"
plot "story.d"  using 1:            804
pause -1
set ylabel "Three Body Parameter Matrix             607"
plot "story.d"  using 1:            805
pause -1
set ylabel "Three Body Parameter Matrix             608"
plot "story.d"  using 1:            806
pause -1
set ylabel "Three Body Parameter Matrix             609"
plot "story.d"  using 1:            807
pause -1
set ylabel "Three Body Parameter Matrix             610"
plot "story.d"  using 1:            808
pause -1
set ylabel "Three Body Parameter Matrix             611"
plot "story.d"  using 1:            809
pause -1
set ylabel "Three Body Parameter Matrix             612"
plot "story.d"  using 1:            810
pause -1
set ylabel "Three Body Parameter Matrix             613"
plot "story.d"  using 1:            811
pause -1
set ylabel "Three Body Parameter Matrix             614"
plot "story.d"  using 1:            812
pause -1
set ylabel "Three Body Parameter Matrix             615"
plot "story.d"  using 1:            813
pause -1
set ylabel "Three Body Parameter Matrix             616"
plot "story.d"  using 1:            814
pause -1
set ylabel "Three Body Parameter Matrix             617"
plot "story.d"  using 1:            815
pause -1
set ylabel "Three Body Parameter Matrix             618"
plot "story.d"  using 1:            816
pause -1
set ylabel "Three Body Parameter Matrix             619"
plot "story.d"  using 1:            817
pause -1
set ylabel "Three Body Parameter Matrix             620"
plot "story.d"  using 1:            818
pause -1
set ylabel "Three Body Parameter Matrix             621"
plot "story.d"  using 1:            819
pause -1
set ylabel "Three Body Parameter Matrix             622"
plot "story.d"  using 1:            820
pause -1
set ylabel "Three Body Parameter Matrix             623"
plot "story.d"  using 1:            821
pause -1
set ylabel "Three Body Parameter Matrix             624"
plot "story.d"  using 1:            822
pause -1
set ylabel "Three Body Parameter Matrix             625"
plot "story.d"  using 1:            823
pause -1
set ylabel "Three Body Parameter Matrix             626"
plot "story.d"  using 1:            824
pause -1
set ylabel "Three Body Parameter Matrix             627"
plot "story.d"  using 1:            825
pause -1
set ylabel "Three Body Parameter Matrix             628"
plot "story.d"  using 1:            826
pause -1
set ylabel "Three Body Parameter Matrix             629"
plot "story.d"  using 1:            827
pause -1
set ylabel "Three Body Parameter Matrix             630"
plot "story.d"  using 1:            828
pause -1
set ylabel "Three Body Parameter Matrix             631"
plot "story.d"  using 1:            829
pause -1
set ylabel "Three Body Parameter Matrix             632"
plot "story.d"  using 1:            830
pause -1
set ylabel "Three Body Parameter Matrix             633"
plot "story.d"  using 1:            831
pause -1
set ylabel "Three Body Parameter Matrix             634"
plot "story.d"  using 1:            832
pause -1
set ylabel "Three Body Parameter Matrix             635"
plot "story.d"  using 1:            833
pause -1
set ylabel "Three Body Parameter Matrix             636"
plot "story.d"  using 1:            834
pause -1
set ylabel "Three Body Parameter Matrix             637"
plot "story.d"  using 1:            835
pause -1
set ylabel "Three Body Parameter Matrix             638"
plot "story.d"  using 1:            836
pause -1
set ylabel "Three Body Parameter Matrix             639"
plot "story.d"  using 1:            837
pause -1
set ylabel "Three Body Parameter Matrix             640"
plot "story.d"  using 1:            838
pause -1
set ylabel "Three Body Parameter Matrix             641"
plot "story.d"  using 1:            839
pause -1
set ylabel "Three Body Parameter Matrix             642"
plot "story.d"  using 1:            840
pause -1
set ylabel "Three Body Parameter Matrix             643"
plot "story.d"  using 1:            841
pause -1
set ylabel "Three Body Parameter Matrix             644"
plot "story.d"  using 1:            842
pause -1
set ylabel "Three Body Parameter Matrix             645"
plot "story.d"  using 1:            843
pause -1
set ylabel "Three Body Parameter Matrix             646"
plot "story.d"  using 1:            844
pause -1
set ylabel "Three Body Parameter Matrix             647"
plot "story.d"  using 1:            845
pause -1
set ylabel "Three Body Parameter Matrix             648"
plot "story.d"  using 1:            846
pause -1
set ylabel "Three Body Parameter Matrix             649"
plot "story.d"  using 1:            847
pause -1
set ylabel "Three Body Parameter Matrix             650"
plot "story.d"  using 1:            848
pause -1
set ylabel "Three Body Parameter Matrix             651"
plot "story.d"  using 1:            849
pause -1
set ylabel "Three Body Parameter Matrix             652"
plot "story.d"  using 1:            850
pause -1
set ylabel "Three Body Parameter Matrix             653"
plot "story.d"  using 1:            851
pause -1
set ylabel "Three Body Parameter Matrix             654"
plot "story.d"  using 1:            852
pause -1
set ylabel "Three Body Parameter Matrix             655"
plot "story.d"  using 1:            853
pause -1
set ylabel "Three Body Parameter Matrix             656"
plot "story.d"  using 1:            854
pause -1
set ylabel "Three Body Parameter Matrix             657"
plot "story.d"  using 1:            855
pause -1
set ylabel "Three Body Parameter Matrix             658"
plot "story.d"  using 1:            856
pause -1
set ylabel "Three Body Parameter Matrix             659"
plot "story.d"  using 1:            857
pause -1
set ylabel "Three Body Parameter Matrix             660"
plot "story.d"  using 1:            858
pause -1
set ylabel "Three Body Parameter Matrix             661"
plot "story.d"  using 1:            859
pause -1
set ylabel "Three Body Parameter Matrix             662"
plot "story.d"  using 1:            860
pause -1
set ylabel "Three Body Parameter Matrix             663"
plot "story.d"  using 1:            861
pause -1
set ylabel "Three Body Parameter Matrix             664"
plot "story.d"  using 1:            862
pause -1
set ylabel "Three Body Parameter Matrix             665"
plot "story.d"  using 1:            863
pause -1
set ylabel "Three Body Parameter Matrix             666"
plot "story.d"  using 1:            864
pause -1
set ylabel "Three Body Parameter Matrix             667"
plot "story.d"  using 1:            865
pause -1
set ylabel "Three Body Parameter Matrix             668"
plot "story.d"  using 1:            866
pause -1
set ylabel "Three Body Parameter Matrix             669"
plot "story.d"  using 1:            867
pause -1
set ylabel "Three Body Parameter Matrix             670"
plot "story.d"  using 1:            868
pause -1
set ylabel "Three Body Parameter Matrix             671"
plot "story.d"  using 1:            869
pause -1
set ylabel "Three Body Parameter Matrix             672"
plot "story.d"  using 1:            870
pause -1
set ylabel "Three Body Parameter Matrix             673"
plot "story.d"  using 1:            871
pause -1
set ylabel "Three Body Parameter Matrix             674"
plot "story.d"  using 1:            872
pause -1
set ylabel "Three Body Parameter Matrix             675"
plot "story.d"  using 1:            873
pause -1
set ylabel "Three Body Parameter Matrix             676"
plot "story.d"  using 1:            874
pause -1
set ylabel "Three Body Parameter Matrix             677"
plot "story.d"  using 1:            875
pause -1
set ylabel "Three Body Parameter Matrix             678"
plot "story.d"  using 1:            876
pause -1
set ylabel "Three Body Parameter Matrix             679"
plot "story.d"  using 1:            877
pause -1
set ylabel "Three Body Parameter Matrix             680"
plot "story.d"  using 1:            878
pause -1
set ylabel "Three Body Parameter Matrix             681"
plot "story.d"  using 1:            879
pause -1
set ylabel "Three Body Parameter Matrix             682"
plot "story.d"  using 1:            880
pause -1
set ylabel "Three Body Parameter Matrix             683"
plot "story.d"  using 1:            881
pause -1
set ylabel "Three Body Parameter Matrix             684"
plot "story.d"  using 1:            882
pause -1
set ylabel "Three Body Parameter Matrix             685"
plot "story.d"  using 1:            883
pause -1
set ylabel "Three Body Parameter Matrix             686"
plot "story.d"  using 1:            884
pause -1
set ylabel "Three Body Parameter Matrix             687"
plot "story.d"  using 1:            885
pause -1
set ylabel "Three Body Parameter Matrix             688"
plot "story.d"  using 1:            886
pause -1
set ylabel "Three Body Parameter Matrix             689"
plot "story.d"  using 1:            887
pause -1
set ylabel "Three Body Parameter Matrix             690"
plot "story.d"  using 1:            888
pause -1
set ylabel "Three Body Parameter Matrix             691"
plot "story.d"  using 1:            889
pause -1
set ylabel "Three Body Parameter Matrix             692"
plot "story.d"  using 1:            890
pause -1
set ylabel "Three Body Parameter Matrix             693"
plot "story.d"  using 1:            891
pause -1
set ylabel "Three Body Parameter Matrix             694"
plot "story.d"  using 1:            892
pause -1
set ylabel "Three Body Parameter Matrix             695"
plot "story.d"  using 1:            893
pause -1
set ylabel "Three Body Parameter Matrix             696"
plot "story.d"  using 1:            894
pause -1
set ylabel "Three Body Parameter Matrix             697"
plot "story.d"  using 1:            895
pause -1
set ylabel "Three Body Parameter Matrix             698"
plot "story.d"  using 1:            896
pause -1
set ylabel "Three Body Parameter Matrix             699"
plot "story.d"  using 1:            897
pause -1
set ylabel "Three Body Parameter Matrix             700"
plot "story.d"  using 1:            898
pause -1
set ylabel "Three Body Parameter Matrix             701"
plot "story.d"  using 1:            899
pause -1
set ylabel "Three Body Parameter Matrix             702"
plot "story.d"  using 1:            900
pause -1
set ylabel  "Det Matrix               1"
plot "story.d"  using 1:            901
pause -1
set ylabel  "Det Matrix               2"
plot "story.d"  using 1:            902
pause -1
set ylabel  "Det Matrix               3"
plot "story.d"  using 1:            903
pause -1
set ylabel  "Det Matrix               4"
plot "story.d"  using 1:            904
pause -1
set ylabel  "Det Matrix               5"
plot "story.d"  using 1:            905
pause -1
set ylabel  "Det Matrix               6"
plot "story.d"  using 1:            906
pause -1
set ylabel  "Det Matrix               7"
plot "story.d"  using 1:            907
pause -1
set ylabel  "Det Matrix               8"
plot "story.d"  using 1:            908
pause -1
set ylabel  "Det Matrix               9"
plot "story.d"  using 1:            909
pause -1
set ylabel  "Det Matrix              10"
plot "story.d"  using 1:            910
pause -1
set ylabel  "Det Matrix              11"
plot "story.d"  using 1:            911
pause -1
set ylabel  "Det Matrix              12"
plot "story.d"  using 1:            912
pause -1
set ylabel  "Det Matrix              13"
plot "story.d"  using 1:            913
pause -1
set ylabel  "Det Matrix              14"
plot "story.d"  using 1:            914
pause -1
set ylabel  "Det Matrix              15"
plot "story.d"  using 1:            915
pause -1
set ylabel  "Det Matrix              16"
plot "story.d"  using 1:            916
pause -1
set ylabel  "Det Matrix              17"
plot "story.d"  using 1:            917
pause -1
set ylabel  "Det Matrix              18"
plot "story.d"  using 1:            918
pause -1
set ylabel  "Det Matrix              19"
plot "story.d"  using 1:            919
pause -1
set ylabel  "Det Matrix              20"
plot "story.d"  using 1:            920
pause -1
set ylabel  "Det Matrix              21"
plot "story.d"  using 1:            921
pause -1
set ylabel  "Det Matrix              22"
plot "story.d"  using 1:            922
pause -1
set ylabel  "Det Matrix              23"
plot "story.d"  using 1:            923
pause -1
set ylabel  "Det Matrix              24"
plot "story.d"  using 1:            924
pause -1
set ylabel  "Det Matrix              25"
plot "story.d"  using 1:            925
pause -1
set ylabel  "Det Matrix              26"
plot "story.d"  using 1:            926
pause -1
set ylabel  "Det Matrix              27"
plot "story.d"  using 1:            927
pause -1
set ylabel  "Det Matrix              28"
plot "story.d"  using 1:            928
pause -1
q
