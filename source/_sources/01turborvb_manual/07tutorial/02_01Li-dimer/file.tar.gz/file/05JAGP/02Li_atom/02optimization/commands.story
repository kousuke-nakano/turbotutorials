set title "Fort.22 Par"
set xlabel "x"
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              2
pause -1
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              3
pause -1
set ylabel  "Orbital Z Parameter               1"
plot "story.d"  using 1:              4
pause -1
set ylabel  "Orbital Z Parameter               2"
plot "story.d"  using 1:              5
pause -1
set ylabel  "Orbital Z Parameter               3"
plot "story.d"  using 1:              6
pause -1
set ylabel  "Orbital Z Parameter               4"
plot "story.d"  using 1:              7
pause -1
set ylabel  "Orbital Z Parameter               5"
plot "story.d"  using 1:              8
pause -1
set ylabel  "Orbital Z Parameter               6"
plot "story.d"  using 1:              9
pause -1
set ylabel  "Orbital Z Parameter               7"
plot "story.d"  using 1:             10
pause -1
set ylabel  "Orbital Z Parameter               8"
plot "story.d"  using 1:             11
pause -1
set ylabel  "Orbital Z Parameter               9"
plot "story.d"  using 1:             12
pause -1
set ylabel  "Orbital Z Parameter              10"
plot "story.d"  using 1:             13
pause -1
set ylabel  "Orbital Z Parameter              11"
plot "story.d"  using 1:             14
pause -1
set ylabel  "Orbital Z Parameter              12"
plot "story.d"  using 1:             15
pause -1
set ylabel  "Orbital Z Parameter              13"
plot "story.d"  using 1:             16
pause -1
set ylabel  "Orbital Z Parameter              14"
plot "story.d"  using 1:             17
pause -1
set ylabel  "Orbital Z Parameter              15"
plot "story.d"  using 1:             18
pause -1
set ylabel  "Orbital Z Parameter              16"
plot "story.d"  using 1:             19
pause -1
set ylabel  "Orbital Z Parameter              17"
plot "story.d"  using 1:             20
pause -1
set ylabel  "Orbital Z Parameter              18"
plot "story.d"  using 1:             21
pause -1
set ylabel  "Orbital Z Parameter              19"
plot "story.d"  using 1:             22
pause -1
set ylabel  "Orbital Z Parameter              20"
plot "story.d"  using 1:             23
pause -1
set ylabel  "Orbital Z Parameter              21"
plot "story.d"  using 1:             24
pause -1
set ylabel  "Orbital Z Parameter              22"
plot "story.d"  using 1:             25
pause -1
set ylabel  "Orbital Z Parameter              23"
plot "story.d"  using 1:             26
pause -1
set ylabel  "Orbital Z Parameter              24"
plot "story.d"  using 1:             27
pause -1
set ylabel  "Orbital Z Parameter              25"
plot "story.d"  using 1:             28
pause -1
set ylabel  "Orbital Z Parameter              26"
plot "story.d"  using 1:             29
pause -1
set ylabel  "Orbital Z Parameter              27"
plot "story.d"  using 1:             30
pause -1
set ylabel  "Orbital Z Parameter              28"
plot "story.d"  using 1:             31
pause -1
set ylabel  "Orbital Z Parameter              29"
plot "story.d"  using 1:             32
pause -1
set ylabel  "Orbital Z Parameter              30"
plot "story.d"  using 1:             33
pause -1
set ylabel  "Orbital Z Parameter              31"
plot "story.d"  using 1:             34
pause -1
set ylabel  "Orbital Z Parameter              32"
plot "story.d"  using 1:             35
pause -1
set ylabel  "Orbital Z Parameter              33"
plot "story.d"  using 1:             36
pause -1
set ylabel  "Orbital Z Parameter              34"
plot "story.d"  using 1:             37
pause -1
set ylabel  "Orbital Z Parameter              35"
plot "story.d"  using 1:             38
pause -1
set ylabel  "Orbital Z Parameter              36"
plot "story.d"  using 1:             39
pause -1
set ylabel  "Orbital Z Parameter              37"
plot "story.d"  using 1:             40
pause -1
set ylabel  "Orbital Z Parameter              38"
plot "story.d"  using 1:             41
pause -1
set ylabel  "Orbital Z Parameter              39"
plot "story.d"  using 1:             42
pause -1
set ylabel  "Orbital Z Parameter              40"
plot "story.d"  using 1:             43
pause -1
set ylabel  "Orbital Z Parameter              41"
plot "story.d"  using 1:             44
pause -1
set ylabel  "Orbital Z Parameter              42"
plot "story.d"  using 1:             45
pause -1
set ylabel  "Orbital Z Parameter              43"
plot "story.d"  using 1:             46
pause -1
set ylabel  "Orbital Z Parameter              44"
plot "story.d"  using 1:             47
pause -1
set ylabel  "Orbital Z Parameter              45"
plot "story.d"  using 1:             48
pause -1
set ylabel  "Orbital Z Parameter              46"
plot "story.d"  using 1:             49
pause -1
set ylabel  "Orbital Z Parameter              47"
plot "story.d"  using 1:             50
pause -1
set ylabel  "Orbital Z Parameter              48"
plot "story.d"  using 1:             51
pause -1
set ylabel  "Orbital Z Parameter              49"
plot "story.d"  using 1:             52
pause -1
set ylabel  "Orbital Z Parameter              50"
plot "story.d"  using 1:             53
pause -1
set ylabel  "Orbital Z Parameter              51"
plot "story.d"  using 1:             54
pause -1
set ylabel  "Orbital Z Parameter              52"
plot "story.d"  using 1:             55
pause -1
set ylabel  "Orbital Z Parameter              53"
plot "story.d"  using 1:             56
pause -1
set ylabel  "Orbital Z Parameter              54"
plot "story.d"  using 1:             57
pause -1
set ylabel  "Orbital Z Parameter              55"
plot "story.d"  using 1:             58
pause -1
set ylabel  "Orbital Z Parameter              56"
plot "story.d"  using 1:             59
pause -1
set ylabel  "Orbital Z Parameter              57"
plot "story.d"  using 1:             60
pause -1
set ylabel  "Orbital Z Parameter              58"
plot "story.d"  using 1:             61
pause -1
set ylabel  "Orbital Z Parameter              59"
plot "story.d"  using 1:             62
pause -1
set ylabel  "Orbital Z Parameter              60"
plot "story.d"  using 1:             63
pause -1
set ylabel  "Orbital Z Parameter              61"
plot "story.d"  using 1:             64
pause -1
set ylabel  "Orbital Z Parameter              62"
plot "story.d"  using 1:             65
pause -1
set ylabel  "Orbital Z Parameter              63"
plot "story.d"  using 1:             66
pause -1
set ylabel  "Orbital Z Parameter              64"
plot "story.d"  using 1:             67
pause -1
set ylabel  "Orbital Z Parameter              65"
plot "story.d"  using 1:             68
pause -1
set ylabel  "Orbital Z Parameter              66"
plot "story.d"  using 1:             69
pause -1
set ylabel  "Orbital Z Parameter              67"
plot "story.d"  using 1:             70
pause -1
set ylabel  "Orbital Z Parameter              68"
plot "story.d"  using 1:             71
pause -1
set ylabel  "Orbital Z Parameter              69"
plot "story.d"  using 1:             72
pause -1
set ylabel  "Orbital Z Parameter              70"
plot "story.d"  using 1:             73
pause -1
set ylabel  "Orbital Z Parameter              71"
plot "story.d"  using 1:             74
pause -1
set ylabel  "Orbital Z Parameter              72"
plot "story.d"  using 1:             75
pause -1
set ylabel  "Orbital Z Parameter              73"
plot "story.d"  using 1:             76
pause -1
set ylabel  "Orbital Z Parameter              74"
plot "story.d"  using 1:             77
pause -1
set ylabel  "Orbital Z Parameter              75"
plot "story.d"  using 1:             78
pause -1
set ylabel  "Orbital Z Parameter              76"
plot "story.d"  using 1:             79
pause -1
set ylabel  "Orbital Z Parameter              77"
plot "story.d"  using 1:             80
pause -1
set ylabel  "Orbital Z Parameter              78"
plot "story.d"  using 1:             81
pause -1
set ylabel  "Orbital Z Parameter              79"
plot "story.d"  using 1:             82
pause -1
set ylabel  "Orbital Z Parameter              80"
plot "story.d"  using 1:             83
pause -1
set ylabel  "Orbital Z Parameter              81"
plot "story.d"  using 1:             84
pause -1
set ylabel  "Orbital Z Parameter              82"
plot "story.d"  using 1:             85
pause -1
set ylabel  "Orbital Z Parameter              83"
plot "story.d"  using 1:             86
pause -1
set ylabel  "Orbital Z Parameter              84"
plot "story.d"  using 1:             87
pause -1
set ylabel  "Orbital Z Parameter              85"
plot "story.d"  using 1:             88
pause -1
set ylabel  "Orbital Z Parameter              86"
plot "story.d"  using 1:             89
pause -1
set ylabel  "Orbital Z Parameter              87"
plot "story.d"  using 1:             90
pause -1
set ylabel  "Orbital Z Parameter              88"
plot "story.d"  using 1:             91
pause -1
set ylabel  "Orbital Z Parameter              89"
plot "story.d"  using 1:             92
pause -1
set ylabel  "Orbital Z Parameter              90"
plot "story.d"  using 1:             93
pause -1
set ylabel  "Orbital Z Parameter              91"
plot "story.d"  using 1:             94
pause -1
set ylabel  "Orbital Z Parameter              92"
plot "story.d"  using 1:             95
pause -1
set ylabel  "Orbital Z Parameter              93"
plot "story.d"  using 1:             96
pause -1
set ylabel  "Orbital Z Parameter              94"
plot "story.d"  using 1:             97
pause -1
set ylabel  "Orbital Z Parameter              95"
plot "story.d"  using 1:             98
pause -1
set ylabel  "Orbital Z Parameter              96"
plot "story.d"  using 1:             99
pause -1
set ylabel  "Orbital Z Parameter              97"
plot "story.d"  using 1:            100
pause -1
set ylabel  "Orbital Z Parameter              98"
plot "story.d"  using 1:            101
pause -1
set ylabel  "Orbital Z Parameter              99"
plot "story.d"  using 1:            102
pause -1
set ylabel  "Orbital Z Parameter             100"
plot "story.d"  using 1:            103
pause -1
set ylabel  "Orbital Z Parameter             101"
plot "story.d"  using 1:            104
pause -1
set ylabel  "Orbital Z Parameter             102"
plot "story.d"  using 1:            105
pause -1
set ylabel  "Orbital Z Parameter             103"
plot "story.d"  using 1:            106
pause -1
set ylabel "Three Body Parameter Matrix               1"
plot "story.d"  using 1:            107
pause -1
set ylabel "Three Body Parameter Matrix               2"
plot "story.d"  using 1:            108
pause -1
set ylabel "Three Body Parameter Matrix               3"
plot "story.d"  using 1:            109
pause -1
set ylabel "Three Body Parameter Matrix               4"
plot "story.d"  using 1:            110
pause -1
set ylabel "Three Body Parameter Matrix               5"
plot "story.d"  using 1:            111
pause -1
set ylabel "Three Body Parameter Matrix               6"
plot "story.d"  using 1:            112
pause -1
set ylabel "Three Body Parameter Matrix               7"
plot "story.d"  using 1:            113
pause -1
set ylabel "Three Body Parameter Matrix               8"
plot "story.d"  using 1:            114
pause -1
set ylabel "Three Body Parameter Matrix               9"
plot "story.d"  using 1:            115
pause -1
set ylabel "Three Body Parameter Matrix              10"
plot "story.d"  using 1:            116
pause -1
set ylabel "Three Body Parameter Matrix              11"
plot "story.d"  using 1:            117
pause -1
set ylabel "Three Body Parameter Matrix              12"
plot "story.d"  using 1:            118
pause -1
set ylabel "Three Body Parameter Matrix              13"
plot "story.d"  using 1:            119
pause -1
set ylabel "Three Body Parameter Matrix              14"
plot "story.d"  using 1:            120
pause -1
set ylabel "Three Body Parameter Matrix              15"
plot "story.d"  using 1:            121
pause -1
set ylabel "Three Body Parameter Matrix              16"
plot "story.d"  using 1:            122
pause -1
set ylabel "Three Body Parameter Matrix              17"
plot "story.d"  using 1:            123
pause -1
set ylabel "Three Body Parameter Matrix              18"
plot "story.d"  using 1:            124
pause -1
set ylabel "Three Body Parameter Matrix              19"
plot "story.d"  using 1:            125
pause -1
set ylabel "Three Body Parameter Matrix              20"
plot "story.d"  using 1:            126
pause -1
set ylabel "Three Body Parameter Matrix              21"
plot "story.d"  using 1:            127
pause -1
set ylabel "Three Body Parameter Matrix              22"
plot "story.d"  using 1:            128
pause -1
set ylabel "Three Body Parameter Matrix              23"
plot "story.d"  using 1:            129
pause -1
set ylabel "Three Body Parameter Matrix              24"
plot "story.d"  using 1:            130
pause -1
set ylabel "Three Body Parameter Matrix              25"
plot "story.d"  using 1:            131
pause -1
set ylabel "Three Body Parameter Matrix              26"
plot "story.d"  using 1:            132
pause -1
set ylabel "Three Body Parameter Matrix              27"
plot "story.d"  using 1:            133
pause -1
set ylabel "Three Body Parameter Matrix              28"
plot "story.d"  using 1:            134
pause -1
set ylabel "Three Body Parameter Matrix              29"
plot "story.d"  using 1:            135
pause -1
set ylabel "Three Body Parameter Matrix              30"
plot "story.d"  using 1:            136
pause -1
set ylabel "Three Body Parameter Matrix              31"
plot "story.d"  using 1:            137
pause -1
set ylabel "Three Body Parameter Matrix              32"
plot "story.d"  using 1:            138
pause -1
set ylabel "Three Body Parameter Matrix              33"
plot "story.d"  using 1:            139
pause -1
set ylabel "Three Body Parameter Matrix              34"
plot "story.d"  using 1:            140
pause -1
set ylabel "Three Body Parameter Matrix              35"
plot "story.d"  using 1:            141
pause -1
set ylabel "Three Body Parameter Matrix              36"
plot "story.d"  using 1:            142
pause -1
set ylabel "Three Body Parameter Matrix              37"
plot "story.d"  using 1:            143
pause -1
set ylabel "Three Body Parameter Matrix              38"
plot "story.d"  using 1:            144
pause -1
set ylabel "Three Body Parameter Matrix              39"
plot "story.d"  using 1:            145
pause -1
set ylabel "Three Body Parameter Matrix              40"
plot "story.d"  using 1:            146
pause -1
set ylabel "Three Body Parameter Matrix              41"
plot "story.d"  using 1:            147
pause -1
set ylabel "Three Body Parameter Matrix              42"
plot "story.d"  using 1:            148
pause -1
set ylabel "Three Body Parameter Matrix              43"
plot "story.d"  using 1:            149
pause -1
set ylabel "Three Body Parameter Matrix              44"
plot "story.d"  using 1:            150
pause -1
set ylabel "Three Body Parameter Matrix              45"
plot "story.d"  using 1:            151
pause -1
set ylabel "Three Body Parameter Matrix              46"
plot "story.d"  using 1:            152
pause -1
set ylabel "Three Body Parameter Matrix              47"
plot "story.d"  using 1:            153
pause -1
set ylabel "Three Body Parameter Matrix              48"
plot "story.d"  using 1:            154
pause -1
set ylabel "Three Body Parameter Matrix              49"
plot "story.d"  using 1:            155
pause -1
set ylabel "Three Body Parameter Matrix              50"
plot "story.d"  using 1:            156
pause -1
set ylabel "Three Body Parameter Matrix              51"
plot "story.d"  using 1:            157
pause -1
set ylabel "Three Body Parameter Matrix              52"
plot "story.d"  using 1:            158
pause -1
set ylabel "Three Body Parameter Matrix              53"
plot "story.d"  using 1:            159
pause -1
set ylabel "Three Body Parameter Matrix              54"
plot "story.d"  using 1:            160
pause -1
set ylabel "Three Body Parameter Matrix              55"
plot "story.d"  using 1:            161
pause -1
set ylabel "Three Body Parameter Matrix              56"
plot "story.d"  using 1:            162
pause -1
set ylabel "Three Body Parameter Matrix              57"
plot "story.d"  using 1:            163
pause -1
set ylabel "Three Body Parameter Matrix              58"
plot "story.d"  using 1:            164
pause -1
set ylabel "Three Body Parameter Matrix              59"
plot "story.d"  using 1:            165
pause -1
set ylabel "Three Body Parameter Matrix              60"
plot "story.d"  using 1:            166
pause -1
set ylabel "Three Body Parameter Matrix              61"
plot "story.d"  using 1:            167
pause -1
set ylabel "Three Body Parameter Matrix              62"
plot "story.d"  using 1:            168
pause -1
set ylabel "Three Body Parameter Matrix              63"
plot "story.d"  using 1:            169
pause -1
set ylabel "Three Body Parameter Matrix              64"
plot "story.d"  using 1:            170
pause -1
set ylabel "Three Body Parameter Matrix              65"
plot "story.d"  using 1:            171
pause -1
set ylabel "Three Body Parameter Matrix              66"
plot "story.d"  using 1:            172
pause -1
set ylabel "Three Body Parameter Matrix              67"
plot "story.d"  using 1:            173
pause -1
set ylabel "Three Body Parameter Matrix              68"
plot "story.d"  using 1:            174
pause -1
set ylabel "Three Body Parameter Matrix              69"
plot "story.d"  using 1:            175
pause -1
set ylabel "Three Body Parameter Matrix              70"
plot "story.d"  using 1:            176
pause -1
set ylabel "Three Body Parameter Matrix              71"
plot "story.d"  using 1:            177
pause -1
set ylabel "Three Body Parameter Matrix              72"
plot "story.d"  using 1:            178
pause -1
set ylabel "Three Body Parameter Matrix              73"
plot "story.d"  using 1:            179
pause -1
set ylabel "Three Body Parameter Matrix              74"
plot "story.d"  using 1:            180
pause -1
set ylabel "Three Body Parameter Matrix              75"
plot "story.d"  using 1:            181
pause -1
set ylabel "Three Body Parameter Matrix              76"
plot "story.d"  using 1:            182
pause -1
set ylabel "Three Body Parameter Matrix              77"
plot "story.d"  using 1:            183
pause -1
set ylabel "Three Body Parameter Matrix              78"
plot "story.d"  using 1:            184
pause -1
set ylabel "Three Body Parameter Matrix              79"
plot "story.d"  using 1:            185
pause -1
set ylabel "Three Body Parameter Matrix              80"
plot "story.d"  using 1:            186
pause -1
set ylabel "Three Body Parameter Matrix              81"
plot "story.d"  using 1:            187
pause -1
set ylabel "Three Body Parameter Matrix              82"
plot "story.d"  using 1:            188
pause -1
set ylabel "Three Body Parameter Matrix              83"
plot "story.d"  using 1:            189
pause -1
set ylabel "Three Body Parameter Matrix              84"
plot "story.d"  using 1:            190
pause -1
set ylabel "Three Body Parameter Matrix              85"
plot "story.d"  using 1:            191
pause -1
set ylabel "Three Body Parameter Matrix              86"
plot "story.d"  using 1:            192
pause -1
set ylabel "Three Body Parameter Matrix              87"
plot "story.d"  using 1:            193
pause -1
set ylabel "Three Body Parameter Matrix              88"
plot "story.d"  using 1:            194
pause -1
set ylabel "Three Body Parameter Matrix              89"
plot "story.d"  using 1:            195
pause -1
set ylabel "Three Body Parameter Matrix              90"
plot "story.d"  using 1:            196
pause -1
set ylabel "Three Body Parameter Matrix              91"
plot "story.d"  using 1:            197
pause -1
set ylabel "Three Body Parameter Matrix              92"
plot "story.d"  using 1:            198
pause -1
set ylabel "Three Body Parameter Matrix              93"
plot "story.d"  using 1:            199
pause -1
set ylabel "Three Body Parameter Matrix              94"
plot "story.d"  using 1:            200
pause -1
set ylabel "Three Body Parameter Matrix              95"
plot "story.d"  using 1:            201
pause -1
set ylabel "Three Body Parameter Matrix              96"
plot "story.d"  using 1:            202
pause -1
set ylabel "Three Body Parameter Matrix              97"
plot "story.d"  using 1:            203
pause -1
set ylabel "Three Body Parameter Matrix              98"
plot "story.d"  using 1:            204
pause -1
set ylabel "Three Body Parameter Matrix              99"
plot "story.d"  using 1:            205
pause -1
set ylabel "Three Body Parameter Matrix             100"
plot "story.d"  using 1:            206
pause -1
set ylabel "Three Body Parameter Matrix             101"
plot "story.d"  using 1:            207
pause -1
set ylabel "Three Body Parameter Matrix             102"
plot "story.d"  using 1:            208
pause -1
set ylabel "Three Body Parameter Matrix             103"
plot "story.d"  using 1:            209
pause -1
set ylabel "Three Body Parameter Matrix             104"
plot "story.d"  using 1:            210
pause -1
set ylabel "Three Body Parameter Matrix             105"
plot "story.d"  using 1:            211
pause -1
set ylabel "Three Body Parameter Matrix             106"
plot "story.d"  using 1:            212
pause -1
set ylabel "Three Body Parameter Matrix             107"
plot "story.d"  using 1:            213
pause -1
set ylabel "Three Body Parameter Matrix             108"
plot "story.d"  using 1:            214
pause -1
set ylabel "Three Body Parameter Matrix             109"
plot "story.d"  using 1:            215
pause -1
set ylabel "Three Body Parameter Matrix             110"
plot "story.d"  using 1:            216
pause -1
set ylabel "Three Body Parameter Matrix             111"
plot "story.d"  using 1:            217
pause -1
set ylabel "Three Body Parameter Matrix             112"
plot "story.d"  using 1:            218
pause -1
set ylabel "Three Body Parameter Matrix             113"
plot "story.d"  using 1:            219
pause -1
set ylabel "Three Body Parameter Matrix             114"
plot "story.d"  using 1:            220
pause -1
set ylabel "Three Body Parameter Matrix             115"
plot "story.d"  using 1:            221
pause -1
set ylabel "Three Body Parameter Matrix             116"
plot "story.d"  using 1:            222
pause -1
set ylabel "Three Body Parameter Matrix             117"
plot "story.d"  using 1:            223
pause -1
set ylabel "Three Body Parameter Matrix             118"
plot "story.d"  using 1:            224
pause -1
set ylabel "Three Body Parameter Matrix             119"
plot "story.d"  using 1:            225
pause -1
set ylabel "Three Body Parameter Matrix             120"
plot "story.d"  using 1:            226
pause -1
set ylabel "Three Body Parameter Matrix             121"
plot "story.d"  using 1:            227
pause -1
set ylabel "Three Body Parameter Matrix             122"
plot "story.d"  using 1:            228
pause -1
set ylabel "Three Body Parameter Matrix             123"
plot "story.d"  using 1:            229
pause -1
set ylabel "Three Body Parameter Matrix             124"
plot "story.d"  using 1:            230
pause -1
set ylabel "Three Body Parameter Matrix             125"
plot "story.d"  using 1:            231
pause -1
set ylabel "Three Body Parameter Matrix             126"
plot "story.d"  using 1:            232
pause -1
set ylabel "Three Body Parameter Matrix             127"
plot "story.d"  using 1:            233
pause -1
set ylabel "Three Body Parameter Matrix             128"
plot "story.d"  using 1:            234
pause -1
set ylabel "Three Body Parameter Matrix             129"
plot "story.d"  using 1:            235
pause -1
set ylabel "Three Body Parameter Matrix             130"
plot "story.d"  using 1:            236
pause -1
set ylabel "Three Body Parameter Matrix             131"
plot "story.d"  using 1:            237
pause -1
set ylabel "Three Body Parameter Matrix             132"
plot "story.d"  using 1:            238
pause -1
set ylabel "Three Body Parameter Matrix             133"
plot "story.d"  using 1:            239
pause -1
set ylabel "Three Body Parameter Matrix             134"
plot "story.d"  using 1:            240
pause -1
set ylabel "Three Body Parameter Matrix             135"
plot "story.d"  using 1:            241
pause -1
set ylabel "Three Body Parameter Matrix             136"
plot "story.d"  using 1:            242
pause -1
set ylabel "Three Body Parameter Matrix             137"
plot "story.d"  using 1:            243
pause -1
set ylabel "Three Body Parameter Matrix             138"
plot "story.d"  using 1:            244
pause -1
set ylabel "Three Body Parameter Matrix             139"
plot "story.d"  using 1:            245
pause -1
set ylabel "Three Body Parameter Matrix             140"
plot "story.d"  using 1:            246
pause -1
set ylabel "Three Body Parameter Matrix             141"
plot "story.d"  using 1:            247
pause -1
set ylabel "Three Body Parameter Matrix             142"
plot "story.d"  using 1:            248
pause -1
set ylabel "Three Body Parameter Matrix             143"
plot "story.d"  using 1:            249
pause -1
set ylabel "Three Body Parameter Matrix             144"
plot "story.d"  using 1:            250
pause -1
set ylabel  "Det Matrix               1"
plot "story.d"  using 1:            251
pause -1
set ylabel  "Det Matrix               2"
plot "story.d"  using 1:            252
pause -1
set ylabel  "Det Matrix               3"
plot "story.d"  using 1:            253
pause -1
set ylabel  "Det Matrix               4"
plot "story.d"  using 1:            254
pause -1
set ylabel  "Det Matrix               5"
plot "story.d"  using 1:            255
pause -1
set ylabel  "Det Matrix               6"
plot "story.d"  using 1:            256
pause -1
q
