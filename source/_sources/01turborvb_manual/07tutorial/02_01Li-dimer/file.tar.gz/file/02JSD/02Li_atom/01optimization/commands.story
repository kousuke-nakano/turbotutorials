set title "Fort.22 Par"
set xlabel "x"
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              2
pause -1
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              3
pause -1
set ylabel "Three Body Parameter Matrix               1"
plot "story.d"  using 1:              4
pause -1
set ylabel "Three Body Parameter Matrix               2"
plot "story.d"  using 1:              5
pause -1
set ylabel "Three Body Parameter Matrix               3"
plot "story.d"  using 1:              6
pause -1
set ylabel "Three Body Parameter Matrix               4"
plot "story.d"  using 1:              7
pause -1
set ylabel "Three Body Parameter Matrix               5"
plot "story.d"  using 1:              8
pause -1
set ylabel "Three Body Parameter Matrix               6"
plot "story.d"  using 1:              9
pause -1
set ylabel "Three Body Parameter Matrix               7"
plot "story.d"  using 1:             10
pause -1
set ylabel "Three Body Parameter Matrix               8"
plot "story.d"  using 1:             11
pause -1
set ylabel "Three Body Parameter Matrix               9"
plot "story.d"  using 1:             12
pause -1
set ylabel "Three Body Parameter Matrix              10"
plot "story.d"  using 1:             13
pause -1
set ylabel "Three Body Parameter Matrix              11"
plot "story.d"  using 1:             14
pause -1
set ylabel "Three Body Parameter Matrix              12"
plot "story.d"  using 1:             15
pause -1
set ylabel  "Det Matrix               1"
plot "story.d"  using 1:             16
pause -1
set ylabel  "Det Matrix               2"
plot "story.d"  using 1:             17
pause -1
set ylabel  "Det Matrix               3"
plot "story.d"  using 1:             18
pause -1
set ylabel  "Det Matrix               4"
plot "story.d"  using 1:             19
pause -1
set ylabel  "Det Matrix               5"
plot "story.d"  using 1:             20
pause -1
set ylabel  "Det Matrix               6"
plot "story.d"  using 1:             21
pause -1
set ylabel  "Det Matrix               7"
plot "story.d"  using 1:             22
pause -1
set ylabel  "Det Matrix               8"
plot "story.d"  using 1:             23
pause -1
set ylabel  "Det Matrix               9"
plot "story.d"  using 1:             24
pause -1
set ylabel  "Det Matrix              10"
plot "story.d"  using 1:             25
pause -1
set ylabel  "Det Matrix              11"
plot "story.d"  using 1:             26
pause -1
set ylabel  "Det Matrix              12"
plot "story.d"  using 1:             27
pause -1
set ylabel  "Det Matrix              13"
plot "story.d"  using 1:             28
pause -1
set ylabel  "Det Matrix              14"
plot "story.d"  using 1:             29
pause -1
set ylabel  "Det Matrix              15"
plot "story.d"  using 1:             30
pause -1
set ylabel  "Det Matrix              16"
plot "story.d"  using 1:             31
pause -1
set ylabel  "Det Matrix              17"
plot "story.d"  using 1:             32
pause -1
set ylabel  "Det Matrix              18"
plot "story.d"  using 1:             33
pause -1
set ylabel  "Det Matrix              19"
plot "story.d"  using 1:             34
pause -1
set ylabel  "Det Matrix              20"
plot "story.d"  using 1:             35
pause -1
set ylabel  "Det Matrix              21"
plot "story.d"  using 1:             36
pause -1
set ylabel  "Det Matrix              22"
plot "story.d"  using 1:             37
pause -1
set ylabel  "Det Matrix              23"
plot "story.d"  using 1:             38
pause -1
set ylabel  "Det Matrix              24"
plot "story.d"  using 1:             39
pause -1
set ylabel  "Det Matrix              25"
plot "story.d"  using 1:             40
pause -1
set ylabel  "Det Matrix              26"
plot "story.d"  using 1:             41
pause -1
set ylabel  "Det Matrix              27"
plot "story.d"  using 1:             42
pause -1
set ylabel  "Det Matrix              28"
plot "story.d"  using 1:             43
pause -1
set ylabel  "Det Matrix              29"
plot "story.d"  using 1:             44
pause -1
set ylabel  "Det Matrix              30"
plot "story.d"  using 1:             45
pause -1
set ylabel  "Det Matrix              31"
plot "story.d"  using 1:             46
pause -1
set ylabel  "Det Matrix              32"
plot "story.d"  using 1:             47
pause -1
set ylabel  "Det Matrix              33"
plot "story.d"  using 1:             48
pause -1
set ylabel  "Det Matrix              34"
plot "story.d"  using 1:             49
pause -1
set ylabel  "Det Matrix              35"
plot "story.d"  using 1:             50
pause -1
set ylabel  "Det Matrix              36"
plot "story.d"  using 1:             51
pause -1
set ylabel  "Det Matrix              37"
plot "story.d"  using 1:             52
pause -1
set ylabel  "Det Matrix              38"
plot "story.d"  using 1:             53
pause -1
set ylabel  "Det Matrix              39"
plot "story.d"  using 1:             54
pause -1
set ylabel  "Det Matrix              40"
plot "story.d"  using 1:             55
pause -1
set ylabel  "Det Matrix              41"
plot "story.d"  using 1:             56
pause -1
set ylabel  "Det Matrix              42"
plot "story.d"  using 1:             57
pause -1
set ylabel  "Det Matrix              43"
plot "story.d"  using 1:             58
pause -1
set ylabel  "Det Matrix              44"
plot "story.d"  using 1:             59
pause -1
set ylabel  "Det Matrix              45"
plot "story.d"  using 1:             60
pause -1
set ylabel  "Det Matrix              46"
plot "story.d"  using 1:             61
pause -1
set ylabel  "Det Matrix              47"
plot "story.d"  using 1:             62
pause -1
set ylabel  "Det Matrix              48"
plot "story.d"  using 1:             63
pause -1
set ylabel  "Det Matrix              49"
plot "story.d"  using 1:             64
pause -1
set ylabel  "Det Matrix              50"
plot "story.d"  using 1:             65
pause -1
set ylabel  "Det Matrix              51"
plot "story.d"  using 1:             66
pause -1
set ylabel  "Det Matrix              52"
plot "story.d"  using 1:             67
pause -1
q
