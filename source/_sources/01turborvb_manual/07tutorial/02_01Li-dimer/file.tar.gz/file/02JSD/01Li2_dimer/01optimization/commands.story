set title "Fort.22 Par"
set xlabel "x"
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              2
pause -1
set ylabel  "Jastrow Two Body"
plot "story.d"  using 1:              3
pause -1
set ylabel "Three Body Parameter Matrix               1"
plot "story.d"  using 1:              4
pause -1
set ylabel "Three Body Parameter Matrix               2"
plot "story.d"  using 1:              5
pause -1
set ylabel "Three Body Parameter Matrix               3"
plot "story.d"  using 1:              6
pause -1
set ylabel "Three Body Parameter Matrix               4"
plot "story.d"  using 1:              7
pause -1
set ylabel "Three Body Parameter Matrix               5"
plot "story.d"  using 1:              8
pause -1
set ylabel "Three Body Parameter Matrix               6"
plot "story.d"  using 1:              9
pause -1
set ylabel "Three Body Parameter Matrix               7"
plot "story.d"  using 1:             10
pause -1
set ylabel "Three Body Parameter Matrix               8"
plot "story.d"  using 1:             11
pause -1
set ylabel "Three Body Parameter Matrix               9"
plot "story.d"  using 1:             12
pause -1
set ylabel "Three Body Parameter Matrix              10"
plot "story.d"  using 1:             13
pause -1
set ylabel "Three Body Parameter Matrix              11"
plot "story.d"  using 1:             14
pause -1
set ylabel "Three Body Parameter Matrix              12"
plot "story.d"  using 1:             15
pause -1
set ylabel "Three Body Parameter Matrix              13"
plot "story.d"  using 1:             16
pause -1
set ylabel "Three Body Parameter Matrix              14"
plot "story.d"  using 1:             17
pause -1
set ylabel "Three Body Parameter Matrix              15"
plot "story.d"  using 1:             18
pause -1
set ylabel "Three Body Parameter Matrix              16"
plot "story.d"  using 1:             19
pause -1
set ylabel "Three Body Parameter Matrix              17"
plot "story.d"  using 1:             20
pause -1
set ylabel "Three Body Parameter Matrix              18"
plot "story.d"  using 1:             21
pause -1
set ylabel "Three Body Parameter Matrix              19"
plot "story.d"  using 1:             22
pause -1
set ylabel "Three Body Parameter Matrix              20"
plot "story.d"  using 1:             23
pause -1
set ylabel "Three Body Parameter Matrix              21"
plot "story.d"  using 1:             24
pause -1
set ylabel "Three Body Parameter Matrix              22"
plot "story.d"  using 1:             25
pause -1
set ylabel "Three Body Parameter Matrix              23"
plot "story.d"  using 1:             26
pause -1
set ylabel "Three Body Parameter Matrix              24"
plot "story.d"  using 1:             27
pause -1
set ylabel "Three Body Parameter Matrix              25"
plot "story.d"  using 1:             28
pause -1
set ylabel "Three Body Parameter Matrix              26"
plot "story.d"  using 1:             29
pause -1
set ylabel "Three Body Parameter Matrix              27"
plot "story.d"  using 1:             30
pause -1
set ylabel "Three Body Parameter Matrix              28"
plot "story.d"  using 1:             31
pause -1
set ylabel "Three Body Parameter Matrix              29"
plot "story.d"  using 1:             32
pause -1
set ylabel "Three Body Parameter Matrix              30"
plot "story.d"  using 1:             33
pause -1
set ylabel "Three Body Parameter Matrix              31"
plot "story.d"  using 1:             34
pause -1
set ylabel "Three Body Parameter Matrix              32"
plot "story.d"  using 1:             35
pause -1
set ylabel "Three Body Parameter Matrix              33"
plot "story.d"  using 1:             36
pause -1
set ylabel "Three Body Parameter Matrix              34"
plot "story.d"  using 1:             37
pause -1
set ylabel "Three Body Parameter Matrix              35"
plot "story.d"  using 1:             38
pause -1
set ylabel "Three Body Parameter Matrix              36"
plot "story.d"  using 1:             39
pause -1
set ylabel "Three Body Parameter Matrix              37"
plot "story.d"  using 1:             40
pause -1
set ylabel "Three Body Parameter Matrix              38"
plot "story.d"  using 1:             41
pause -1
set ylabel "Three Body Parameter Matrix              39"
plot "story.d"  using 1:             42
pause -1
set ylabel "Three Body Parameter Matrix              40"
plot "story.d"  using 1:             43
pause -1
set ylabel "Three Body Parameter Matrix              41"
plot "story.d"  using 1:             44
pause -1
set ylabel  "Det Matrix               1"
plot "story.d"  using 1:             45
pause -1
set ylabel  "Det Matrix               2"
plot "story.d"  using 1:             46
pause -1
set ylabel  "Det Matrix               3"
plot "story.d"  using 1:             47
pause -1
set ylabel  "Det Matrix               4"
plot "story.d"  using 1:             48
pause -1
set ylabel  "Det Matrix               5"
plot "story.d"  using 1:             49
pause -1
set ylabel  "Det Matrix               6"
plot "story.d"  using 1:             50
pause -1
set ylabel  "Det Matrix               7"
plot "story.d"  using 1:             51
pause -1
set ylabel  "Det Matrix               8"
plot "story.d"  using 1:             52
pause -1
set ylabel  "Det Matrix               9"
plot "story.d"  using 1:             53
pause -1
set ylabel  "Det Matrix              10"
plot "story.d"  using 1:             54
pause -1
set ylabel  "Det Matrix              11"
plot "story.d"  using 1:             55
pause -1
set ylabel  "Det Matrix              12"
plot "story.d"  using 1:             56
pause -1
set ylabel  "Det Matrix              13"
plot "story.d"  using 1:             57
pause -1
set ylabel  "Det Matrix              14"
plot "story.d"  using 1:             58
pause -1
set ylabel  "Det Matrix              15"
plot "story.d"  using 1:             59
pause -1
set ylabel  "Det Matrix              16"
plot "story.d"  using 1:             60
pause -1
set ylabel  "Det Matrix              17"
plot "story.d"  using 1:             61
pause -1
set ylabel  "Det Matrix              18"
plot "story.d"  using 1:             62
pause -1
set ylabel  "Det Matrix              19"
plot "story.d"  using 1:             63
pause -1
set ylabel  "Det Matrix              20"
plot "story.d"  using 1:             64
pause -1
set ylabel  "Det Matrix              21"
plot "story.d"  using 1:             65
pause -1
set ylabel  "Det Matrix              22"
plot "story.d"  using 1:             66
pause -1
set ylabel  "Det Matrix              23"
plot "story.d"  using 1:             67
pause -1
set ylabel  "Det Matrix              24"
plot "story.d"  using 1:             68
pause -1
set ylabel  "Det Matrix              25"
plot "story.d"  using 1:             69
pause -1
set ylabel  "Det Matrix              26"
plot "story.d"  using 1:             70
pause -1
set ylabel  "Det Matrix              27"
plot "story.d"  using 1:             71
pause -1
set ylabel  "Det Matrix              28"
plot "story.d"  using 1:             72
pause -1
set ylabel  "Det Matrix              29"
plot "story.d"  using 1:             73
pause -1
set ylabel  "Det Matrix              30"
plot "story.d"  using 1:             74
pause -1
set ylabel  "Det Matrix              31"
plot "story.d"  using 1:             75
pause -1
set ylabel  "Det Matrix              32"
plot "story.d"  using 1:             76
pause -1
set ylabel  "Det Matrix              33"
plot "story.d"  using 1:             77
pause -1
set ylabel  "Det Matrix              34"
plot "story.d"  using 1:             78
pause -1
set ylabel  "Det Matrix              35"
plot "story.d"  using 1:             79
pause -1
set ylabel  "Det Matrix              36"
plot "story.d"  using 1:             80
pause -1
set ylabel  "Det Matrix              37"
plot "story.d"  using 1:             81
pause -1
set ylabel  "Det Matrix              38"
plot "story.d"  using 1:             82
pause -1
set ylabel  "Det Matrix              39"
plot "story.d"  using 1:             83
pause -1
set ylabel  "Det Matrix              40"
plot "story.d"  using 1:             84
pause -1
set ylabel  "Det Matrix              41"
plot "story.d"  using 1:             85
pause -1
set ylabel  "Det Matrix              42"
plot "story.d"  using 1:             86
pause -1
set ylabel  "Det Matrix              43"
plot "story.d"  using 1:             87
pause -1
set ylabel  "Det Matrix              44"
plot "story.d"  using 1:             88
pause -1
set ylabel  "Det Matrix              45"
plot "story.d"  using 1:             89
pause -1
set ylabel  "Det Matrix              46"
plot "story.d"  using 1:             90
pause -1
set ylabel  "Det Matrix              47"
plot "story.d"  using 1:             91
pause -1
set ylabel  "Det Matrix              48"
plot "story.d"  using 1:             92
pause -1
set ylabel  "Det Matrix              49"
plot "story.d"  using 1:             93
pause -1
set ylabel  "Det Matrix              50"
plot "story.d"  using 1:             94
pause -1
set ylabel  "Det Matrix              51"
plot "story.d"  using 1:             95
pause -1
set ylabel  "Det Matrix              52"
plot "story.d"  using 1:             96
pause -1
set ylabel  "Det Matrix              53"
plot "story.d"  using 1:             97
pause -1
set ylabel  "Det Matrix              54"
plot "story.d"  using 1:             98
pause -1
set ylabel  "Det Matrix              55"
plot "story.d"  using 1:             99
pause -1
set ylabel  "Det Matrix              56"
plot "story.d"  using 1:            100
pause -1
set ylabel  "Det Matrix              57"
plot "story.d"  using 1:            101
pause -1
set ylabel  "Det Matrix              58"
plot "story.d"  using 1:            102
pause -1
set ylabel  "Det Matrix              59"
plot "story.d"  using 1:            103
pause -1
set ylabel  "Det Matrix              60"
plot "story.d"  using 1:            104
pause -1
set ylabel  "Det Matrix              61"
plot "story.d"  using 1:            105
pause -1
set ylabel  "Det Matrix              62"
plot "story.d"  using 1:            106
pause -1
set ylabel  "Det Matrix              63"
plot "story.d"  using 1:            107
pause -1
set ylabel  "Det Matrix              64"
plot "story.d"  using 1:            108
pause -1
set ylabel  "Det Matrix              65"
plot "story.d"  using 1:            109
pause -1
set ylabel  "Det Matrix              66"
plot "story.d"  using 1:            110
pause -1
set ylabel  "Det Matrix              67"
plot "story.d"  using 1:            111
pause -1
set ylabel  "Det Matrix              68"
plot "story.d"  using 1:            112
pause -1
set ylabel  "Det Matrix              69"
plot "story.d"  using 1:            113
pause -1
set ylabel  "Det Matrix              70"
plot "story.d"  using 1:            114
pause -1
set ylabel  "Det Matrix              71"
plot "story.d"  using 1:            115
pause -1
set ylabel  "Det Matrix              72"
plot "story.d"  using 1:            116
pause -1
set ylabel  "Det Matrix              73"
plot "story.d"  using 1:            117
pause -1
set ylabel  "Det Matrix              74"
plot "story.d"  using 1:            118
pause -1
set ylabel  "Det Matrix              75"
plot "story.d"  using 1:            119
pause -1
set ylabel  "Det Matrix              76"
plot "story.d"  using 1:            120
pause -1
set ylabel  "Det Matrix              77"
plot "story.d"  using 1:            121
pause -1
set ylabel  "Det Matrix              78"
plot "story.d"  using 1:            122
pause -1
set ylabel  "Det Matrix              79"
plot "story.d"  using 1:            123
pause -1
set ylabel  "Det Matrix              80"
plot "story.d"  using 1:            124
pause -1
set ylabel  "Det Matrix              81"
plot "story.d"  using 1:            125
pause -1
set ylabel  "Det Matrix              82"
plot "story.d"  using 1:            126
pause -1
set ylabel  "Det Matrix              83"
plot "story.d"  using 1:            127
pause -1
set ylabel  "Det Matrix              84"
plot "story.d"  using 1:            128
pause -1
set ylabel  "Det Matrix              85"
plot "story.d"  using 1:            129
pause -1
set ylabel  "Det Matrix              86"
plot "story.d"  using 1:            130
pause -1
set ylabel  "Det Matrix              87"
plot "story.d"  using 1:            131
pause -1
set ylabel  "Det Matrix              88"
plot "story.d"  using 1:            132
pause -1
set ylabel  "Det Matrix              89"
plot "story.d"  using 1:            133
pause -1
set ylabel  "Det Matrix              90"
plot "story.d"  using 1:            134
pause -1
set ylabel  "Det Matrix              91"
plot "story.d"  using 1:            135
pause -1
set ylabel  "Det Matrix              92"
plot "story.d"  using 1:            136
pause -1
set ylabel  "Det Matrix              93"
plot "story.d"  using 1:            137
pause -1
set ylabel  "Det Matrix              94"
plot "story.d"  using 1:            138
pause -1
set ylabel  "Det Matrix              95"
plot "story.d"  using 1:            139
pause -1
set ylabel  "Det Matrix              96"
plot "story.d"  using 1:            140
pause -1
set ylabel  "Det Matrix              97"
plot "story.d"  using 1:            141
pause -1
set ylabel  "Det Matrix              98"
plot "story.d"  using 1:            142
pause -1
set ylabel  "Det Matrix              99"
plot "story.d"  using 1:            143
pause -1
set ylabel  "Det Matrix             100"
plot "story.d"  using 1:            144
pause -1
set ylabel  "Det Matrix             101"
plot "story.d"  using 1:            145
pause -1
set ylabel  "Det Matrix             102"
plot "story.d"  using 1:            146
pause -1
set ylabel  "Det Matrix             103"
plot "story.d"  using 1:            147
pause -1
set ylabel  "Det Matrix             104"
plot "story.d"  using 1:            148
pause -1
set ylabel  "Det Matrix             105"
plot "story.d"  using 1:            149
pause -1
set ylabel  "Det Matrix             106"
plot "story.d"  using 1:            150
pause -1
set ylabel  "Det Matrix             107"
plot "story.d"  using 1:            151
pause -1
set ylabel  "Det Matrix             108"
plot "story.d"  using 1:            152
pause -1
set ylabel  "Det Matrix             109"
plot "story.d"  using 1:            153
pause -1
set ylabel  "Det Matrix             110"
plot "story.d"  using 1:            154
pause -1
set ylabel  "Det Matrix             111"
plot "story.d"  using 1:            155
pause -1
set ylabel  "Det Matrix             112"
plot "story.d"  using 1:            156
pause -1
set ylabel  "Det Matrix             113"
plot "story.d"  using 1:            157
pause -1
set ylabel  "Det Matrix             114"
plot "story.d"  using 1:            158
pause -1
set ylabel  "Det Matrix             115"
plot "story.d"  using 1:            159
pause -1
set ylabel  "Det Matrix             116"
plot "story.d"  using 1:            160
pause -1
set ylabel  "Det Matrix             117"
plot "story.d"  using 1:            161
pause -1
set ylabel  "Det Matrix             118"
plot "story.d"  using 1:            162
pause -1
set ylabel  "Det Matrix             119"
plot "story.d"  using 1:            163
pause -1
set ylabel  "Det Matrix             120"
plot "story.d"  using 1:            164
pause -1
set ylabel  "Det Matrix             121"
plot "story.d"  using 1:            165
pause -1
set ylabel  "Det Matrix             122"
plot "story.d"  using 1:            166
pause -1
set ylabel  "Det Matrix             123"
plot "story.d"  using 1:            167
pause -1
set ylabel  "Det Matrix             124"
plot "story.d"  using 1:            168
pause -1
set ylabel  "Det Matrix             125"
plot "story.d"  using 1:            169
pause -1
set ylabel  "Det Matrix             126"
plot "story.d"  using 1:            170
pause -1
set ylabel  "Det Matrix             127"
plot "story.d"  using 1:            171
pause -1
set ylabel  "Det Matrix             128"
plot "story.d"  using 1:            172
pause -1
set ylabel  "Det Matrix             129"
plot "story.d"  using 1:            173
pause -1
set ylabel  "Det Matrix             130"
plot "story.d"  using 1:            174
pause -1
set ylabel  "Det Matrix             131"
plot "story.d"  using 1:            175
pause -1
set ylabel  "Det Matrix             132"
plot "story.d"  using 1:            176
pause -1
set ylabel  "Det Matrix             133"
plot "story.d"  using 1:            177
pause -1
set ylabel  "Det Matrix             134"
plot "story.d"  using 1:            178
pause -1
set ylabel  "Det Matrix             135"
plot "story.d"  using 1:            179
pause -1
set ylabel  "Det Matrix             136"
plot "story.d"  using 1:            180
pause -1
set ylabel  "Det Matrix             137"
plot "story.d"  using 1:            181
pause -1
set ylabel  "Det Matrix             138"
plot "story.d"  using 1:            182
pause -1
set ylabel  "Det Matrix             139"
plot "story.d"  using 1:            183
pause -1
set ylabel  "Det Matrix             140"
plot "story.d"  using 1:            184
pause -1
set ylabel  "Det Matrix             141"
plot "story.d"  using 1:            185
pause -1
set ylabel  "Det Matrix             142"
plot "story.d"  using 1:            186
pause -1
set ylabel  "Det Matrix             143"
plot "story.d"  using 1:            187
pause -1
set ylabel  "Det Matrix             144"
plot "story.d"  using 1:            188
pause -1
set ylabel  "Det Matrix             145"
plot "story.d"  using 1:            189
pause -1
set ylabel  "Det Matrix             146"
plot "story.d"  using 1:            190
pause -1
set ylabel  "Det Matrix             147"
plot "story.d"  using 1:            191
pause -1
set ylabel  "Det Matrix             148"
plot "story.d"  using 1:            192
pause -1
set ylabel  "Det Matrix             149"
plot "story.d"  using 1:            193
pause -1
set ylabel  "Det Matrix             150"
plot "story.d"  using 1:            194
pause -1
set ylabel  "Det Matrix             151"
plot "story.d"  using 1:            195
pause -1
set ylabel  "Det Matrix             152"
plot "story.d"  using 1:            196
pause -1
set ylabel  "Det Matrix             153"
plot "story.d"  using 1:            197
pause -1
set ylabel  "Det Matrix             154"
plot "story.d"  using 1:            198
pause -1
set ylabel  "Det Matrix             155"
plot "story.d"  using 1:            199
pause -1
set ylabel  "Det Matrix             156"
plot "story.d"  using 1:            200
pause -1
set ylabel  "Det Matrix             157"
plot "story.d"  using 1:            201
pause -1
set ylabel  "Det Matrix             158"
plot "story.d"  using 1:            202
pause -1
set ylabel  "Det Matrix             159"
plot "story.d"  using 1:            203
pause -1
set ylabel  "Det Matrix             160"
plot "story.d"  using 1:            204
pause -1
set ylabel  "Det Matrix             161"
plot "story.d"  using 1:            205
pause -1
set ylabel  "Det Matrix             162"
plot "story.d"  using 1:            206
pause -1
set ylabel  "Det Matrix             163"
plot "story.d"  using 1:            207
pause -1
set ylabel  "Det Matrix             164"
plot "story.d"  using 1:            208
pause -1
set ylabel  "Det Matrix             165"
plot "story.d"  using 1:            209
pause -1
set ylabel  "Det Matrix             166"
plot "story.d"  using 1:            210
pause -1
set ylabel  "Det Matrix             167"
plot "story.d"  using 1:            211
pause -1
set ylabel  "Det Matrix             168"
plot "story.d"  using 1:            212
pause -1
set ylabel  "Det Matrix             169"
plot "story.d"  using 1:            213
pause -1
set ylabel  "Det Matrix             170"
plot "story.d"  using 1:            214
pause -1
set ylabel  "Det Matrix             171"
plot "story.d"  using 1:            215
pause -1
set ylabel  "Det Matrix             172"
plot "story.d"  using 1:            216
pause -1
set ylabel  "Det Matrix             173"
plot "story.d"  using 1:            217
pause -1
set ylabel  "Det Matrix             174"
plot "story.d"  using 1:            218
pause -1
set ylabel  "Det Matrix             175"
plot "story.d"  using 1:            219
pause -1
set ylabel  "Det Matrix             176"
plot "story.d"  using 1:            220
pause -1
set ylabel  "Det Matrix             177"
plot "story.d"  using 1:            221
pause -1
set ylabel  "Det Matrix             178"
plot "story.d"  using 1:            222
pause -1
set ylabel  "Det Matrix             179"
plot "story.d"  using 1:            223
pause -1
set ylabel  "Det Matrix             180"
plot "story.d"  using 1:            224
pause -1
set ylabel  "Det Matrix             181"
plot "story.d"  using 1:            225
pause -1
set ylabel  "Det Matrix             182"
plot "story.d"  using 1:            226
pause -1
set ylabel  "Det Matrix             183"
plot "story.d"  using 1:            227
pause -1
set ylabel  "Det Matrix             184"
plot "story.d"  using 1:            228
pause -1
set ylabel  "Det Matrix             185"
plot "story.d"  using 1:            229
pause -1
set ylabel  "Det Matrix             186"
plot "story.d"  using 1:            230
pause -1
set ylabel  "Det Matrix             187"
plot "story.d"  using 1:            231
pause -1
set ylabel  "Det Matrix             188"
plot "story.d"  using 1:            232
pause -1
set ylabel  "Det Matrix             189"
plot "story.d"  using 1:            233
pause -1
q
